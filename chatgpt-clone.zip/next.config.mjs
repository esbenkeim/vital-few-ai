/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable static export for GitHub Pages and other static hosting
  output: process.env.NODE_ENV === 'production' ? 'export' : undefined,
  
  // Disable image optimization for static export
  images: {
    unoptimized: true,
  },
  
  // Add base path for GitHub Pages if needed
  basePath: process.env.NODE_ENV === 'production' && process.env.GITHUB_PAGES ? `/${process.env.REPO_NAME}` : '',
  
  // Ensure trailing slash for static hosting
  trailingSlash: true,
  
  // Disable server-side features for static export
  experimental: {
    esmExternals: true,
  },
  
  // ESLint configuration
  eslint: {
    ignoreDuringBuilds: true,
  },
  
  // TypeScript configuration
  typescript: {
    ignoreBuildErrors: true,
  },
}

export default nextConfig
