import { type NextRequest, NextResponse } from "next/server"

// Mock email service - replace with real email service like Resend, SendGrid, etc.
async function sendEmail(to: string, subject: string, html: string) {
  // For demo purposes, we'll log the email content
  console.log("📧 Email sent to:", to)
  console.log("📧 Subject:", subject)
  console.log("📧 Content:", html)

  // In production, replace with actual email service:
  /*
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: 'noreply@vitalfew.com',
      to: [to],
      subject: subject,
      html: html,
    }),
  })
  return response.json()
  */

  // Mock successful response
  return { success: true, id: `mock-${Date.now()}` }
}

export async function POST(req: NextRequest) {
  try {
    const { email, invitedBy } = await req.json()

    if (!email || !invitedBy) {
      return NextResponse.json({ error: "Email and invitedBy are required" }, { status: 400 })
    }

    const invitationHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Invitasjon til Vital Few AI</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { text-align: center; margin-bottom: 30px; }
            .logo { width: 80px; height: 80px; margin: 0 auto 20px; }
            .button { 
              display: inline-block; 
              padding: 12px 24px; 
              background: linear-gradient(135deg, #3b82f6, #8b5cf6); 
              color: white; 
              text-decoration: none; 
              border-radius: 6px; 
              margin: 20px 0;
            }
            .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 14px; color: #666; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">🧠</div>
              <h1>Velkommen til Vital Few AI</h1>
            </div>
            
            <p>Hei!</p>
            
            <p>Du har blitt invitert av <strong>${invitedBy}</strong> til å bli med i Vital Few AI - vår avanserte AI-plattform for prompt-bibliotek og chat.</p>
            
            <p>Med Vital Few AI kan du:</p>
            <ul>
              <li>📚 Administrere og organisere AI-prompts</li>
              <li>💬 Chatte med avanserte AI-modeller</li>
              <li>🔄 Dele prompts med teamet</li>
              <li>📊 Spore bruk og ytelse</li>
            </ul>
            
            <div style="text-align: center;">
              <a href="${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}" class="button">
                Kom i gang nå
              </a>
            </div>
            
            <p>Registrer deg med denne e-postadressen (<strong>${email}</strong>) for å få tilgang til plattformen.</p>
            
            <div class="footer">
              <p>Med vennlig hilsen,<br>Vital Few Team</p>
              <p><small>Denne invitasjonen er personlig og kan ikke overføres til andre.</small></p>
            </div>
          </div>
        </body>
      </html>
    `

    const result = await sendEmail(email, "Invitasjon til Vital Few AI Platform", invitationHtml)

    return NextResponse.json({ success: true, result })
  } catch (error) {
    console.error("Error sending invitation:", error)
    return NextResponse.json({ error: "Failed to send invitation" }, { status: 500 })
  }
}
