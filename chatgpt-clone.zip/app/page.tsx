"use client"

import { useRef } from "react"

import { useState, useEffect, useMemo } from "react"
import { useChat } from "ai/react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Textarea } from "@/components/ui/textarea"
import { ThemeProvider } from "@/components/theme-provider"
import { Send, Trash2, Edit3, Check, X, Bot, User, MoreVertical, Square } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useChatHistory } from "@/hooks/use-chat-history"
import { AuthProvider, useAuth } from "@/contexts/auth-context"
import { AuthPage } from "@/components/auth/auth-page"
import { Sidebar } from "@/components/sidebar"
import { PromptGrid } from "@/components/prompt-grid"
import { AddPromptModal } from "@/components/add-prompt-modal"
import { PromptDetailModal } from "@/components/prompt-detail-modal"
import { usePrompts } from "@/hooks/use-prompts"
import { useFilters } from "@/hooks/use-filters"
import type { Prompt } from "@/types/prompt"
import { AdminDashboard } from "@/components/admin/admin-dashboard"
import { SmartNavbar } from "@/components/navigation/smart-navbar"
import { SmartSidebar } from "@/components/navigation/smart-sidebar"
import { useKeyboardShortcuts } from "@/hooks/use-keyboard-shortcuts"
import { toast } from "sonner"

function ChatMessage({ message, onEdit, onDelete, isEditing, editValue, setEditValue, onSaveEdit, onCancelEdit }: any) {
  const isUser = message.role === "user"

  return (
    <div className={`flex gap-3 p-4 ${isUser ? "bg-muted/50" : ""}`}>
      <div className="flex-shrink-0">
        {isUser ? (
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
        ) : (
          <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
            <Bot className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="flex-1 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">{isUser ? "You" : "Assistant"}</span>
          {isUser && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6">
                  <MoreVertical className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(message.id)}>
                  <Edit3 className="h-3 w-3 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onDelete(message.id)} className="text-destructive">
                  <Trash2 className="h-3 w-3 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {isEditing ? (
          <div className="space-y-2">
            <Textarea value={editValue} onChange={(e) => setEditValue(e.target.value)} className="min-h-[60px]" />
            <div className="flex gap-2">
              <Button size="sm" onClick={onSaveEdit}>
                <Check className="h-3 w-3 mr-1" />
                Save
              </Button>
              <Button size="sm" variant="outline" onClick={onCancelEdit}>
                <X className="h-3 w-3 mr-1" />
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <div className="whitespace-pre-wrap">{message.content}</div>
          </div>
        )}
      </div>
    </div>
  )
}

function TypingIndicator() {
  return (
    <div className="flex gap-3 p-4">
      <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
        <Bot className="w-4 h-4" />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-1">
          <span className="text-sm font-medium">Assistant</span>
        </div>
        <div className="flex items-center gap-1 mt-2">
          <div className="flex gap-1">
            <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:-0.3s]"></div>
            <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:-0.15s]"></div>
            <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
          </div>
          <span className="text-sm text-muted-foreground ml-2">Thinking...</span>
        </div>
      </div>
    </div>
  )
}

function ChatInterface({ onViewChange }: { onViewChange: (view: "chat" | "prompts" | "admin") => void }) {
  const [selectedModel, setSelectedModel] = useState("gpt-4o-mini")
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null)
  const [editValue, setEditValue] = useState("")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  const {
    chatSessions,
    currentChatId,
    setCurrentChatId,
    createNewChat,
    updateChatSession,
    deleteChatSession,
    getCurrentChat,
    generateChatTitle,
  } = useChatHistory()

  const currentChat = getCurrentChat()

  const { messages, input, handleInputChange, handleSubmit, isLoading, setMessages, stop } = useChat({
    api: "/api/chat",
    body: { model: selectedModel },
    initialMessages: currentChat?.messages || [],
    onFinish: () => {
      setTimeout(() => {
        scrollAreaRef.current?.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: "smooth" })
      }, 100)
    },
  })

  // Update current chat when messages change
  useEffect(() => {
    if (currentChatId && messages.length > 0) {
      const title = messages.length === 1 ? generateChatTitle(messages) : currentChat?.title || "New Chat"
      updateChatSession(currentChatId, {
        messages,
        title,
        model: selectedModel,
      })
    }
  }, [messages, currentChatId, selectedModel])

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: "smooth" })
    }
  }, [messages])

  const handleSelectChat = (chatId: string) => {
    const chat = chatSessions.find((c) => c.id === chatId)
    if (chat) {
      setCurrentChatId(chatId)
      setMessages(chat.messages)
      setSelectedModel(chat.model)
    }
  }

  const handleCreateNewChat = () => {
    const newChat = createNewChat(selectedModel)
    setMessages([])
  }

  const handleDeleteChat = (chatId: string) => {
    deleteChatSession(chatId)
    if (currentChatId === chatId) {
      setMessages([])
    }
  }

  const handleRenameChat = (chatId: string, newTitle: string) => {
    updateChatSession(chatId, { title: newTitle })
  }

  const handleEdit = (messageId: string) => {
    const message = messages.find((m) => m.id === messageId)
    if (message) {
      setEditingMessageId(messageId)
      setEditValue(message.content)
    }
  }

  const handleSaveEdit = () => {
    if (editingMessageId) {
      const updatedMessages = messages.map((m) => (m.id === editingMessageId ? { ...m, content: editValue } : m))
      setMessages(updatedMessages)
      setEditingMessageId(null)
      setEditValue("")
    }
  }

  const handleCancelEdit = () => {
    setEditingMessageId(null)
    setEditValue("")
  }

  const handleDelete = (messageId: string) => {
    const messageIndex = messages.findIndex((m) => m.id === messageId)
    if (messageIndex !== -1) {
      const updatedMessages = messages.slice(0, messageIndex)
      setMessages(updatedMessages)
    }
  }

  const exportAsMarkdown = () => {
    const markdown = messages
      .map((message) => {
        const role = message.role === "user" ? "**You:**" : "**Assistant:**"
        return `${role}\n\n${message.content}\n\n---\n`
      })
      .join("\n")

    const blob = new Blob([markdown], { type: "text/markdown" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `chat-export-${new Date().toISOString().split("T")[0]}.md`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success("Chat exported successfully!")
  }

  const clearCurrentChat = () => {
    setMessages([])
    if (currentChatId) {
      updateChatSession(currentChatId, { messages: [] })
    }
    toast.success("Chat cleared!")
  }

  const breadcrumbs = currentChat ? [{ label: "Chat" }, { label: currentChat.title }] : [{ label: "Chat" }]

  return (
    <div className="flex h-screen bg-background">
      {/* Smart Sidebar */}
      <SmartSidebar
        currentView="chat"
        onNavigate={(type, id) => {
          switch (type) {
            case "chat":
              if (id) handleSelectChat(id)
              break
            case "new-chat":
              handleCreateNewChat()
              break
            case "new-prompt":
              onViewChange("prompts")
              break
            case "prompt":
              onViewChange("prompts")
              break
          }
        }}
        isCollapsed={sidebarCollapsed}
      />

      {/* Main Chat Area */}
      <div className="flex flex-col flex-1">
        {/* Chat Messages */}
        <ScrollArea className="flex-1" ref={scrollAreaRef}>
          <div className="max-w-4xl mx-auto">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full p-8">
                <div className="text-center space-y-4">
                  <Bot className="h-12 w-12 mx-auto text-muted-foreground" />
                  <div className="space-y-2">
                    <h2 className="text-xl font-semibold">How can I help you today?</h2>
                    <p className="text-muted-foreground">Start a conversation with Vital Few AI assistant</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="divide-y">
                {messages.map((message) => (
                  <ChatMessage
                    key={message.id}
                    message={message}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                    isEditing={editingMessageId === message.id}
                    editValue={editValue}
                    setEditValue={setEditValue}
                    onSaveEdit={handleSaveEdit}
                    onCancelEdit={handleCancelEdit}
                  />
                ))}
                {isLoading && <TypingIndicator />}
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="max-w-4xl mx-auto p-4">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <div className="flex-1 relative">
                <Input
                  value={input}
                  onChange={handleInputChange}
                  placeholder="Message Vital Few AI..."
                  className="pr-12"
                  disabled={isLoading}
                />
                {isLoading ? (
                  <Button
                    type="button"
                    size="icon"
                    variant="destructive"
                    className="absolute right-1 top-1 h-8 w-8"
                    onClick={stop}
                    title="Stop generation"
                  >
                    <Square className="h-4 w-4" />
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    size="icon"
                    className="absolute right-1 top-1 h-8 w-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                    disabled={!input.trim()}
                    title="Send message"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </form>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              Vital Few AI can make mistakes. Consider checking important information.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function ProtectedApp() {
  const { user, isLoading, logout } = useAuth()

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <Bot className="h-12 w-12 mx-auto text-muted-foreground animate-pulse" />
          <p className="text-muted-foreground">Loading Vital Few AI...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return <AuthPage />
  }

  return <MainApp />
}

function MainApp() {
  const [currentView, setCurrentView] = useState<"chat" | "prompts" | "admin">("prompts")
  const [addModalOpen, setAddModalOpen] = useState(false)
  const [detailModalOpen, setDetailModalOpen] = useState(false)
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null)
  const [editingPrompt, setEditingPrompt] = useState<Prompt | null>(null)
  const { isAdmin, logout } = useAuth()

  const {
    prompts,
    addPrompt,
    updatePrompt,
    deletePrompt,
    toggleFavorite,
    incrementUsage,
    exportPrompts,
    importPrompts,
  } = usePrompts()
  const {
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    selectedModel,
    setSelectedModel,
    sortBy,
    setSortBy,
  } = useFilters()

  // Keyboard shortcuts
  useKeyboardShortcuts([
    {
      key: "k",
      metaKey: true,
      action: () => {
        // Global search will be handled by SmartNavbar
      },
      description: "Open global search",
    },
    {
      key: "n",
      metaKey: true,
      action: () => {
        if (currentView === "chat") {
          // Create new chat
        } else {
          setAddModalOpen(true)
        }
      },
      description: "New chat or prompt",
    },
    {
      key: "p",
      metaKey: true,
      action: () => {
        setCurrentView("prompts")
        setAddModalOpen(true)
      },
      description: "New prompt",
    },
    {
      key: "1",
      metaKey: true,
      action: () => setCurrentView("chat"),
      description: "Switch to chat",
    },
    {
      key: "2",
      metaKey: true,
      action: () => setCurrentView("prompts"),
      description: "Switch to prompts",
    },
    {
      key: "3",
      metaKey: true,
      action: () => isAdmin && setCurrentView("admin"),
      description: "Switch to admin (admin only)",
    },
  ])

  // Filter and sort prompts
  const filteredPrompts = useMemo(() => {
    const filtered = prompts.filter((prompt) => {
      const matchesSearch =
        searchQuery === "" ||
        prompt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prompt.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prompt.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prompt.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

      const matchesCategory = selectedCategory === "all" || prompt.category === selectedCategory
      const matchesModel = selectedModel === "all" || prompt.aiModel === selectedModel

      return matchesSearch && matchesCategory && matchesModel
    })

    // Sort prompts
    switch (sortBy) {
      case "newest":
        return filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      case "oldest":
        return filtered.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
      case "mostUsed":
        return filtered.sort((a, b) => b.usageCount - a.usageCount)
      case "rating":
        return filtered.sort((a, b) => b.rating - a.rating)
      default:
        return filtered
    }
  }, [prompts, searchQuery, selectedCategory, selectedModel, sortBy])

  const handleQuickAction = (action: string, data?: any) => {
    switch (action) {
      case "new-chat":
        setCurrentView("chat")
        break
      case "new-prompt":
        setAddModalOpen(true)
        break
      case "view-prompt":
        if (data) {
          const prompt = prompts.find((p) => p.id === data)
          if (prompt) {
            setSelectedPrompt(prompt)
            setDetailModalOpen(true)
            incrementUsage(prompt.id)
          }
        }
        break
      case "logout":
        logout()
        break
      case "export-data":
        exportPrompts()
        toast.success("Data exported successfully!")
        break
    }
  }

  const handleEditPrompt = (prompt: Prompt) => {
    setEditingPrompt(prompt)
    setAddModalOpen(true)
  }

  const handleViewPrompt = (prompt: Prompt) => {
    setSelectedPrompt(prompt)
    setDetailModalOpen(true)
    incrementUsage(prompt.id)
  }

  const handleCopyPrompt = (content: string) => {
    navigator.clipboard.writeText(content)
    toast.success("Prompt copied to clipboard!")
  }

  const handleCloseAddModal = () => {
    setAddModalOpen(false)
    setEditingPrompt(null)
  }

  const getBreadcrumbs = () => {
    switch (currentView) {
      case "chat":
        return [{ label: "Chat" }]
      case "prompts":
        return [{ label: "Prompt Library" }]
      case "admin":
        return [{ label: "Admin Dashboard" }]
      default:
        return []
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <SmartNavbar
        currentView={currentView}
        onViewChange={setCurrentView}
        onQuickAction={handleQuickAction}
        breadcrumbs={getBreadcrumbs()}
      />

      {currentView === "chat" && <ChatInterface onViewChange={setCurrentView} />}

      {currentView === "prompts" && (
        <div className="flex">
          <Sidebar
            isOpen={false}
            onClose={() => {}}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            selectedModel={selectedModel}
            onModelChange={setSelectedModel}
            sortBy={sortBy}
            onSortChange={setSortBy}
            prompts={prompts}
          />

          <main className="flex-1 p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Vital Few Prompt Library</h2>
              <p className="text-muted-foreground">Manage and organize your AI prompts for optimal productivity</p>
            </div>

            <PromptGrid
              prompts={filteredPrompts}
              onEdit={handleEditPrompt}
              onDelete={deletePrompt}
              onView={handleViewPrompt}
              onCopy={handleCopyPrompt}
              onToggleFavorite={toggleFavorite}
            />
          </main>
        </div>
      )}

      {currentView === "admin" && isAdmin && <AdminDashboard />}

      <AddPromptModal
        isOpen={addModalOpen}
        onClose={handleCloseAddModal}
        onSave={editingPrompt ? updatePrompt : addPrompt}
        editingPrompt={editingPrompt}
      />

      <PromptDetailModal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        prompt={selectedPrompt}
        onCopy={handleCopyPrompt}
        onEdit={handleEditPrompt}
      />
    </div>
  )
}

export default function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <AuthProvider>
        <ProtectedApp />
      </AuthProvider>
    </ThemeProvider>
  )
}
