"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  email: string
  name: string
  createdAt: Date
  isAdmin: boolean
}

interface WhitelistEntry {
  id: string
  email: string
  invitedBy: string
  invitedAt: Date
  isUsed: boolean
  usedAt?: Date
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; message?: string }>
  logout: () => void
  isLoading: boolean
  // Admin functions
  isAdmin: boolean
  whitelist: WhitelistEntry[]
  addToWhitelist: (email: string) => Promise<boolean>
  removeFromWhitelist: (id: string) => void
  getAllUsers: () => User[]
  deleteUser: (userId: string) => void
  makeAdmin: (userId: string) => void
  removeAdmin: (userId: string) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

interface AuthProviderProps {
  children: ReactNode
}

// Admin email - change this to your email
const ADMIN_EMAIL = "admin@vitalfew.com"

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [whitelist, setWhitelist] = useState<WhitelistEntry[]>([])

  useEffect(() => {
    // Check if user is logged in on app start
    const savedUser = localStorage.getItem("vital-few-user")
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser)
        setUser({
          ...userData,
          createdAt: new Date(userData.createdAt),
        })
      } catch (error) {
        console.error("Error parsing saved user:", error)
        localStorage.removeItem("vital-few-user")
      }
    }

    // Load whitelist
    const savedWhitelist = localStorage.getItem("vital-few-whitelist")
    if (savedWhitelist) {
      try {
        const whitelistData = JSON.parse(savedWhitelist).map((entry: any) => ({
          ...entry,
          invitedAt: new Date(entry.invitedAt),
          usedAt: entry.usedAt ? new Date(entry.usedAt) : undefined,
        }))
        setWhitelist(whitelistData)
      } catch (error) {
        console.error("Error parsing whitelist:", error)
      }
    } else {
      // Initialize with admin email
      const adminEntry: WhitelistEntry = {
        id: "admin-entry",
        email: ADMIN_EMAIL,
        invitedBy: "System",
        invitedAt: new Date(),
        isUsed: false,
      }
      setWhitelist([adminEntry])
      localStorage.setItem("vital-few-whitelist", JSON.stringify([adminEntry]))
    }

    setIsLoading(false)
  }, [])

  useEffect(() => {
    if (whitelist.length > 0) {
      localStorage.setItem("vital-few-whitelist", JSON.stringify(whitelist))
    }
  }, [whitelist])

  const isEmailWhitelisted = (email: string): boolean => {
    return whitelist.some((entry) => entry.email.toLowerCase() === email.toLowerCase())
  }

  const markWhitelistAsUsed = (email: string) => {
    setWhitelist((prev) =>
      prev.map((entry) =>
        entry.email.toLowerCase() === email.toLowerCase() ? { ...entry, isUsed: true, usedAt: new Date() } : entry,
      ),
    )
  }

  const register = async (
    name: string,
    email: string,
    password: string,
  ): Promise<{ success: boolean; message?: string }> => {
    try {
      // Check if email is whitelisted
      if (!isEmailWhitelisted(email)) {
        return {
          success: false,
          message: "Du må være invitert for å registrere deg. Kontakt administrator for tilgang.",
        }
      }

      // Get existing users
      const existingUsers = JSON.parse(localStorage.getItem("vital-few-users") || "[]")

      // Check if user already exists
      if (existingUsers.find((u: any) => u.email === email)) {
        return { success: false, message: "En bruker med denne e-postadressen eksisterer allerede." }
      }

      // Create new user
      const newUser: User = {
        id: Date.now().toString(),
        email,
        name,
        createdAt: new Date(),
        isAdmin: email.toLowerCase() === ADMIN_EMAIL.toLowerCase(),
      }

      // Save user credentials
      const userWithPassword = { ...newUser, password }
      existingUsers.push(userWithPassword)
      localStorage.setItem("vital-few-users", JSON.stringify(existingUsers))

      // Mark whitelist entry as used
      markWhitelistAsUsed(email)

      // Log user in
      setUser(newUser)
      localStorage.setItem("vital-few-user", JSON.stringify(newUser))

      return { success: true }
    } catch (error) {
      console.error("Registration error:", error)
      return { success: false, message: "En feil oppstod under registrering." }
    }
  }

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Get existing users
      const existingUsers = JSON.parse(localStorage.getItem("vital-few-users") || "[]")

      // Find user with matching credentials
      const foundUser = existingUsers.find((u: any) => u.email === email && u.password === password)

      if (foundUser) {
        const { password: _, ...userWithoutPassword } = foundUser
        const userData = {
          ...userWithoutPassword,
          createdAt: new Date(foundUser.createdAt),
          isAdmin: foundUser.email.toLowerCase() === ADMIN_EMAIL.toLowerCase() || foundUser.isAdmin,
        }

        setUser(userData)
        localStorage.setItem("vital-few-user", JSON.stringify(userData))
        return true
      }

      return false
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("vital-few-user")
  }

  const addToWhitelist = async (email: string): Promise<boolean> => {
    try {
      if (isEmailWhitelisted(email)) {
        return false // Already whitelisted
      }

      const newEntry: WhitelistEntry = {
        id: Date.now().toString(),
        email: email.toLowerCase(),
        invitedBy: user?.name || "Admin",
        invitedAt: new Date(),
        isUsed: false,
      }

      setWhitelist((prev) => [...prev, newEntry])

      // Send invitation email
      const response = await fetch("/api/send-invitation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          invitedBy: user?.name || "Admin",
        }),
      })

      return response.ok
    } catch (error) {
      console.error("Error adding to whitelist:", error)
      return false
    }
  }

  const removeFromWhitelist = (id: string) => {
    setWhitelist((prev) => prev.filter((entry) => entry.id !== id))
  }

  const getAllUsers = (): User[] => {
    try {
      const users = JSON.parse(localStorage.getItem("vital-few-users") || "[]")
      return users.map((u: any) => ({
        id: u.id,
        email: u.email,
        name: u.name,
        createdAt: new Date(u.createdAt),
        isAdmin: u.isAdmin || u.email.toLowerCase() === ADMIN_EMAIL.toLowerCase(),
      }))
    } catch (error) {
      console.error("Error getting users:", error)
      return []
    }
  }

  const deleteUser = (userId: string) => {
    try {
      const users = JSON.parse(localStorage.getItem("vital-few-users") || "[]")
      const updatedUsers = users.filter((u: any) => u.id !== userId)
      localStorage.setItem("vital-few-users", JSON.stringify(updatedUsers))
    } catch (error) {
      console.error("Error deleting user:", error)
    }
  }

  const makeAdmin = (userId: string) => {
    try {
      const users = JSON.parse(localStorage.getItem("vital-few-users") || "[]")
      const updatedUsers = users.map((u: any) => (u.id === userId ? { ...u, isAdmin: true } : u))
      localStorage.setItem("vital-few-users", JSON.stringify(updatedUsers))
    } catch (error) {
      console.error("Error making admin:", error)
    }
  }

  const removeAdmin = (userId: string) => {
    try {
      const users = JSON.parse(localStorage.getItem("vital-few-users") || "[]")
      const updatedUsers = users.map((u: any) =>
        u.id === userId && u.email.toLowerCase() !== ADMIN_EMAIL.toLowerCase() ? { ...u, isAdmin: false } : u,
      )
      localStorage.setItem("vital-few-users", JSON.stringify(updatedUsers))
    } catch (error) {
      console.error("Error removing admin:", error)
    }
  }

  const isAdmin = user?.isAdmin || false

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        isLoading,
        isAdmin,
        whitelist,
        addToWhitelist,
        removeFromWhitelist,
        getAllUsers,
        deleteUser,
        makeAdmin,
        removeAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}
