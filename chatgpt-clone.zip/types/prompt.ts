export interface Prompt {
  id: string
  title: string
  description: string
  content: string
  category: Category
  aiModel: AIModel
  tags: string[]
  rating: number
  isFavorite: boolean
  usageCount: number
  createdAt: string
  updatedAt: string
}

export type Category = "productivity" | "creative" | "analysis" | "coding" | "coaching" | "general"

export type AIModel = "gpt-4" | "gpt-4-turbo" | "gpt-3.5-turbo" | "groq-llama" | "groq-mixtral" | "claude"

export type SortOption = "newest" | "oldest" | "mostUsed" | "rating"

export const CATEGORIES = {
  productivity: {
    name: "Produktivitet & Planlegging",
    color: "bg-blue-500",
    textColor: "text-blue-700",
    bgColor: "bg-blue-50",
  },
  creative: { name: "Kreativ Skriving", color: "bg-purple-500", textColor: "text-purple-700", bgColor: "bg-purple-50" },
  analysis: { name: "Dataanalyse", color: "bg-green-500", textColor: "text-green-700", bgColor: "bg-green-50" },
  coding: { name: "Kodegenerering", color: "bg-orange-500", textColor: "text-orange-700", bgColor: "bg-orange-50" },
  coaching: { name: "Coaching & Utvikling", color: "bg-pink-500", textColor: "text-pink-700", bgColor: "bg-pink-50" },
  general: { name: "Generell Bruk", color: "bg-gray-500", textColor: "text-gray-700", bgColor: "bg-gray-50" },
} as const

export const AI_MODELS = {
  "gpt-4": { name: "GPT-4", icon: "🤖", provider: "OpenAI" },
  "gpt-4-turbo": { name: "GPT-4 Turbo", icon: "⚡", provider: "OpenAI" },
  "gpt-3.5-turbo": { name: "GPT-3.5 Turbo", icon: "🔥", provider: "OpenAI" },
  "groq-llama": { name: "Llama 3", icon: "🦙", provider: "Groq" },
  "groq-mixtral": { name: "Mixtral", icon: "🌟", provider: "Groq" },
  claude: { name: "Claude", icon: "🎭", provider: "Anthropic" },
} as const
