"use client"

import { useState, useEffect } from "react"
import type { Prompt } from "@/types/prompt"

const STORAGE_KEY = "ai-prompt-library"

const SAMPLE_PROMPTS: Prompt[] = [
  {
    id: "1",
    title: "Produktivitetsplanlegger",
    description: "Hjelper deg med å planlegge dagen og prioritere oppgaver effektivt",
    content:
      "Du er en ekspert produktivitetscoach. Hjelp meg med å planlegge dagen min ved å:\n\n1. Analysere mine oppgaver og prioritere dem\n2. Foreslå en realistisk tidsplan\n3. Identifisere potensielle hindringer\n4. Gi tips for å holde fokus\n\nMine oppgaver for i dag:\n[SETT INN OPPGAVER HER]",
    category: "productivity",
    aiModel: "gpt-4",
    tags: ["planlegging", "produktivitet", "tidstyring"],
    rating: 5,
    isFavorite: true,
    usageCount: 15,
    createdAt: "2024-01-15T10:00:00Z",
    updatedAt: "2024-01-15T10:00:00Z",
  },
  {
    id: "2",
    title: "Kreativ brainstorming",
    description: "Generer innovative ideer og kreative løsninger for dine prosjekter",
    content:
      "Du er en kreativ brainstorming-partner. Hjelp meg med å generere innovative ideer ved å:\n\n1. Stille utfordrende spørsmål\n2. Foreslå ukonvensjonelle tilnærminger\n3. Bygge videre på mine ideer\n4. Kombinere konsepter på nye måter\n\nMitt prosjekt/utfordring:\n[BESKRIV PROSJEKTET HER]",
    category: "creative",
    aiModel: "gpt-4-turbo",
    tags: ["kreativitet", "brainstorming", "innovasjon"],
    rating: 4,
    isFavorite: false,
    usageCount: 8,
    createdAt: "2024-01-14T14:30:00Z",
    updatedAt: "2024-01-14T14:30:00Z",
  },
  {
    id: "3",
    title: "Kodegjennomgang",
    description: "Få detaljert feedback på koden din med forbedringsforslag",
    content:
      "Du er en senior utvikler som gjennomgår kode. Analyser følgende kode og gi:\n\n1. Identifiser potensielle bugs eller problemer\n2. Foreslå forbedringer i ytelse og lesbarhet\n3. Sjekk for best practices og kodestandarder\n4. Gi konkrete eksempler på forbedringer\n\nKode som skal gjennomgås:\n```\n[SETT INN KODE HER]\n```",
    category: "coding",
    aiModel: "groq-llama",
    tags: ["kode", "review", "kvalitet", "debugging"],
    rating: 5,
    isFavorite: true,
    usageCount: 22,
    createdAt: "2024-01-13T09:15:00Z",
    updatedAt: "2024-01-13T09:15:00Z",
  },
  {
    id: "4",
    title: "Møtereferat generator",
    description: "Lag strukturerte møtereferater fra dine notater",
    content:
      "Du er en profesjonell møtesekretær. Lag et strukturert møtereferat basert på mine notater:\n\n**Format:**\n- Møtedato og deltakere\n- Hovedpunkter diskutert\n- Beslutninger tatt\n- Handlingsplan med ansvarlige og frister\n- Oppfølgingspunkter\n\nMine møtenotater:\n[SETT INN NOTATER HER]",
    category: "productivity",
    aiModel: "gpt-3.5-turbo",
    tags: ["møter", "referat", "dokumentasjon"],
    rating: 4,
    isFavorite: false,
    usageCount: 12,
    createdAt: "2024-01-12T16:45:00Z",
    updatedAt: "2024-01-12T16:45:00Z",
  },
  {
    id: "5",
    title: "Problemløsningscoach",
    description: "Få veiledning gjennom komplekse problemer med strukturert tilnærming",
    content:
      "Du er en erfaren problemløsningscoach. Hjelp meg med å løse mitt problem ved å:\n\n1. Hjelpe meg å definere problemet tydelig\n2. Identifisere grunnårsaker\n3. Brainstorme mulige løsninger\n4. Evaluere alternativer\n5. Lage en handlingsplan\n\nMitt problem/utfordring:\n[BESKRIV PROBLEMET HER]",
    category: "coaching",
    aiModel: "claude",
    tags: ["problemløsning", "coaching", "strategi"],
    rating: 5,
    isFavorite: true,
    usageCount: 18,
    createdAt: "2024-01-11T11:20:00Z",
    updatedAt: "2024-01-11T11:20:00Z",
  },
  {
    id: "6",
    title: "Dataanalyse assistent",
    description: "Analyser data og generer innsikter med visualiseringsforslag",
    content:
      "Du er en dataanalytiker. Hjelp meg med å analysere mine data ved å:\n\n1. Identifisere mønstre og trender\n2. Beregne relevante statistikker\n3. Foreslå visualiseringer\n4. Trekke meningsfulle konklusjoner\n5. Anbefale neste steg\n\nMine data:\n[SETT INN DATA HER]\n\nSpørsmål jeg vil ha svar på:\n[SETT INN SPØRSMÅL HER]",
    category: "analysis",
    aiModel: "gpt-4",
    tags: ["data", "analyse", "statistikk", "visualisering"],
    rating: 4,
    isFavorite: false,
    usageCount: 7,
    createdAt: "2024-01-10T13:10:00Z",
    updatedAt: "2024-01-10T13:10:00Z",
  },
]

export function usePrompts() {
  const [prompts, setPrompts] = useState<Prompt[]>([])

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved) {
      try {
        setPrompts(JSON.parse(saved))
      } catch (error) {
        console.error("Error loading prompts:", error)
        setPrompts(SAMPLE_PROMPTS)
      }
    } else {
      setPrompts(SAMPLE_PROMPTS)
    }
  }, [])

  useEffect(() => {
    if (prompts.length > 0) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(prompts))
    }
  }, [prompts])

  const addPrompt = (promptData: Omit<Prompt, "id" | "createdAt" | "updatedAt" | "usageCount">) => {
    const newPrompt: Prompt = {
      ...promptData,
      id: Date.now().toString(),
      usageCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setPrompts((prev) => [newPrompt, ...prev])
  }

  const updatePrompt = (id: string, updates: Partial<Prompt>) => {
    setPrompts((prev) =>
      prev.map((prompt) =>
        prompt.id === id ? { ...prompt, ...updates, updatedAt: new Date().toISOString() } : prompt,
      ),
    )
  }

  const deletePrompt = (id: string) => {
    setPrompts((prev) => prev.filter((prompt) => prompt.id !== id))
  }

  const toggleFavorite = (id: string) => {
    updatePrompt(id, { isFavorite: !prompts.find((p) => p.id === id)?.isFavorite })
  }

  const incrementUsage = (id: string) => {
    const prompt = prompts.find((p) => p.id === id)
    if (prompt) {
      updatePrompt(id, { usageCount: prompt.usageCount + 1 })
    }
  }

  const exportPrompts = () => {
    const dataStr = JSON.stringify(prompts, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `ai-prompts-${new Date().toISOString().split("T")[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const importPrompts = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string)
        if (Array.isArray(imported)) {
          setPrompts((prev) => [...imported, ...prev])
        }
      } catch (error) {
        console.error("Error importing prompts:", error)
      }
    }
    reader.readAsText(file)
  }

  return {
    prompts,
    addPrompt,
    updatePrompt,
    deletePrompt,
    toggleFavorite,
    incrementUsage,
    exportPrompts,
    importPrompts,
  }
}
