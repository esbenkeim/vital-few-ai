"use client"

import { useEffect } from "react"

interface KeyboardShortcut {
  key: string
  ctrlKey?: boolean
  metaKey?: boolean
  shiftKey?: boolean
  altKey?: boolean
  action: () => void
  description: string
}

export function useKeyboardShortcuts(shortcuts: KeyboardShortcut[]) {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      for (const shortcut of shortcuts) {
        const keyMatch = event.key.toLowerCase() === shortcut.key.toLowerCase()
        const ctrlMatch = !!shortcut.ctrlKey === event.ctrlKey
        const metaMatch = !!shortcut.metaKey === event.metaKey
        const shiftMatch = !!shortcut.shiftKey === event.shiftKey
        const altMatch = !!shortcut.altKey === event.altKey

        if (keyMatch && ctrlMatch && metaMatch && shiftMatch && altMatch) {
          event.preventDefault()
          shortcut.action()
          break
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [shortcuts])
}

export const defaultShortcuts = [
  {
    key: "k",
    metaKey: true,
    action: () => {}, // Will be overridden
    description: "Open global search",
  },
  {
    key: "n",
    metaKey: true,
    action: () => {}, // Will be overridden
    description: "New chat",
  },
  {
    key: "p",
    metaKey: true,
    action: () => {}, // Will be overridden
    description: "New prompt",
  },
  {
    key: "/",
    action: () => {}, // Will be overridden
    description: "Focus search",
  },
  {
    key: "Escape",
    action: () => {}, // Will be overridden
    description: "Close modal/search",
  },
]
