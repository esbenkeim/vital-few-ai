"use client"

import { useState } from "react"
import type { Category, AIModel, SortOption } from "@/types/prompt"

export function useFilters() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<Category | "all">("all")
  const [selectedModel, setSelectedModel] = useState<AIModel | "all">("all")
  const [sortBy, setSortBy] = useState<SortOption>("newest")

  return {
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    selectedModel,
    setSelectedModel,
    sortBy,
    setSortBy,
  }
}
