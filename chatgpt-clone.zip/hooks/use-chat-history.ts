"use client"

import { useState, useEffect } from "react"

export interface ChatSession {
  id: string
  title: string
  messages: any[]
  createdAt: Date
  updatedAt: Date
  model: string
}

export function useChatHistory() {
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([])
  const [currentChatId, setCurrentChatId] = useState<string | null>(null)

  // Load chat history from localStorage on mount
  useEffect(() => {
    const savedSessions = localStorage.getItem("chat-sessions")
    if (savedSessions) {
      const sessions = JSON.parse(savedSessions).map((session: any) => ({
        ...session,
        createdAt: new Date(session.createdAt),
        updatedAt: new Date(session.updatedAt),
      }))
      setChatSessions(sessions)
    }
  }, [])

  // Save to localStorage whenever sessions change
  useEffect(() => {
    if (chatSessions.length > 0) {
      localStorage.setItem("chat-sessions", JSON.stringify(chatSessions))
    }
  }, [chatSessions])

  const createNewChat = (model = "llama-3.1-8b-instant") => {
    const newChat: ChatSession = {
      id: Date.now().toString(),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      model,
    }
    setChatSessions((prev) => [newChat, ...prev])
    setCurrentChatId(newChat.id)
    return newChat
  }

  const updateChatSession = (chatId: string, updates: Partial<ChatSession>) => {
    setChatSessions((prev) =>
      prev.map((session) => (session.id === chatId ? { ...session, ...updates, updatedAt: new Date() } : session)),
    )
  }

  const deleteChatSession = (chatId: string) => {
    setChatSessions((prev) => prev.filter((session) => session.id !== chatId))
    if (currentChatId === chatId) {
      setCurrentChatId(null)
    }
  }

  const getCurrentChat = () => {
    return chatSessions.find((session) => session.id === currentChatId) || null
  }

  const generateChatTitle = (messages: any[]) => {
    const firstUserMessage = messages.find((m) => m.role === "user")?.content
    if (firstUserMessage) {
      return firstUserMessage.slice(0, 50) + (firstUserMessage.length > 50 ? "..." : "")
    }
    return "New Chat"
  }

  return {
    chatSessions,
    currentChatId,
    setCurrentChatId,
    createNewChat,
    updateChatSession,
    deleteChatSession,
    getCurrentChat,
    generateChatTitle,
  }
}
