export const DEPLOYMENT_OPTIONS = {
  vercel: {
    name: "Vercel",
    description: "Deploy directly to Vercel with custom subdomain",
    customUrl: true,
    steps: [
      "Connect GitHub repository to Vercel",
      "Choose custom subdomain (e.g., vital-few-ai.vercel.app)",
      "Deploy automatically on push",
    ],
    example: "https://vital-few-ai.vercel.app",
  },
  netlify: {
    name: "Netlify",
    description: "Deploy to Netlify with custom subdomain",
    customUrl: true,
    steps: [
      "Connect GitHub repository to Netlify",
      "Choose custom subdomain (e.g., vital-few-ai.netlify.app)",
      "Configure build settings",
    ],
    example: "https://vital-few-ai.netlify.app",
  },
  github: {
    name: "GitHub Pages",
    description: "Free hosting with GitHub Pages",
    customUrl: true,
    steps: [
      "Enable GitHub Pages in repository settings",
      "Choose custom subdomain (e.g., username.github.io/vital-few-ai)",
      "Configure GitHub Actions for deployment",
    ],
    example: "https://username.github.io/vital-few-ai",
  },
  railway: {
    name: "Railway",
    description: "Deploy to Railway with custom subdomain",
    customUrl: true,
    steps: [
      "Connect GitHub repository to Railway",
      "Choose custom subdomain (e.g., vital-few-ai.railway.app)",
      "Configure environment variables",
    ],
    example: "https://vital-few-ai.railway.app",
  },
  render: {
    name: "Render",
    description: "Deploy to Render with custom subdomain",
    customUrl: true,
    steps: [
      "Connect GitHub repository to Render",
      "Choose custom subdomain (e.g., vital-few-ai.onrender.com)",
      "Configure build and start commands",
    ],
    example: "https://vital-few-ai.onrender.com",
  },
}

export const CUSTOM_SUBDOMAIN_SUGGESTIONS = [
  "vital-few-ai",
  "vitalfew-ai",
  "vital-ai-platform",
  "vf-ai-platform",
  "vital-few-chat",
  "vitalfew-prompts",
  "ai-prompt-library",
  "vital-ai-workspace",
  "vf-ai-assistant",
  "vital-few-studio",
]
