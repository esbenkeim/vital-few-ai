export const AI_MODELS = {
  Groq: {
    name: "Groq",
    models: [
      {
        id: "llama-3.1-8b-instant",
        name: "Llama 3 8B Instant",
      },
    ],
  },
  OpenAI: {
    name: "OpenAI",
    models: [
      {
        id: "gpt-4o-mini",
        name: "GPT-4o Mini",
      },
    ],
  },
}
