"use client"

interface ModelIndicatorProps {
  model: string
}

export function ModelIndicator({ model }: ModelIndicatorProps) {
  const getProviderInfo = (modelId: string) => {
    if (
      modelId.startsWith("gpt-") ||
      modelId.startsWith("o1") ||
      modelId.startsWith("o3") ||
      modelId.startsWith("o4")
    ) {
      return { provider: "OpenAI", color: "bg-green-500" }
    } else {
      return { provider: "Groq", color: "bg-blue-500" }
    }
  }

  const { provider, color } = getProviderInfo(model)

  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${color}`} />
      <span className="text-xs text-muted-foreground">{provider}</span>
    </div>
  )
}
