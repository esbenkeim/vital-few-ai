"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Star, X } from "lucide-react"
import { CATEGORIES, AI_MODELS, type Prompt, type Category, type AIModel } from "@/types/prompt"

interface AddPromptModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (prompt: any) => void
  editingPrompt?: Prompt | null
}

export function AddPromptModal({ isOpen, onClose, onSave, editingPrompt }: AddPromptModalProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [content, setContent] = useState("")
  const [category, setCategory] = useState<Category>("general")
  const [aiModel, setAiModel] = useState<AIModel>("gpt-4")
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState("")
  const [rating, setRating] = useState(3)

  useEffect(() => {
    if (editingPrompt) {
      setTitle(editingPrompt.title)
      setDescription(editingPrompt.description)
      setContent(editingPrompt.content)
      setCategory(editingPrompt.category)
      setAiModel(editingPrompt.aiModel)
      setTags(editingPrompt.tags)
      setRating(editingPrompt.rating)
    } else {
      // Reset form
      setTitle("")
      setDescription("")
      setContent("")
      setCategory("general")
      setAiModel("gpt-4")
      setTags([])
      setTagInput("")
      setRating(3)
    }
  }, [editingPrompt, isOpen])

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()])
      setTagInput("")
    }
  }

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault()
      handleAddTag()
    }
  }

  const handleSave = () => {
    if (!title.trim() || !content.trim()) return

    const promptData = {
      title: title.trim(),
      description: description.trim(),
      content: content.trim(),
      category,
      aiModel,
      tags,
      rating,
      isFavorite: editingPrompt?.isFavorite || false,
    }

    if (editingPrompt) {
      onSave(editingPrompt.id, promptData)
    } else {
      onSave(promptData)
    }

    onClose()
  }

  const renderStars = () => {
    return Array.from({ length: 5 }, (_, i) => (
      <Button key={i} variant="ghost" size="icon" className="h-8 w-8 p-0" onClick={() => setRating(i + 1)}>
        <Star className={`h-4 w-4 ${i < rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`} />
      </Button>
    ))
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editingPrompt ? "Rediger Prompt" : "Legg til Ny Prompt"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Tittel *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Skriv inn prompt-tittel..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beskrivelse</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Kort beskrivelse av hva denne prompten gjør..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Hovedprompt *</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Skriv inn den fullstendige prompten her..."
              rows={8}
              className="font-mono text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Kategori</Label>
              <Select value={category} onValueChange={(value) => setCategory(value as Category)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORIES).map(([key, cat]) => (
                    <SelectItem key={key} value={key}>
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${cat.color}`} />
                        {cat.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>AI Modell</Label>
              <Select value={aiModel} onValueChange={(value) => setAiModel(value as AIModel)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(AI_MODELS).map(([key, model]) => (
                    <SelectItem key={key} value={key}>
                      {model.icon} {model.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Tags</Label>
            <div className="flex flex-wrap gap-2 mb-2">
              {tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                  {tag}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 hover:bg-transparent"
                    onClick={() => handleRemoveTag(tag)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Legg til tags (trykk Enter eller komma)"
              />
              <Button type="button" variant="outline" onClick={handleAddTag}>
                Legg til
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Rating</Label>
            <div className="flex items-center gap-1">{renderStars()}</div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Avbryt
          </Button>
          <Button onClick={handleSave} disabled={!title.trim() || !content.trim()}>
            {editingPrompt ? "Oppdater" : "Lagre"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
