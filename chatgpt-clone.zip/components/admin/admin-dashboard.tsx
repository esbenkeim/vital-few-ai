"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Users,
  UserPlus,
  Mail,
  Shield,
  ShieldCheck,
  Trash2,
  MoreVertical,
  CheckCircle,
  Clock,
  AlertCircle,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"

export function AdminDashboard() {
  const { whitelist, addToWhitelist, removeFromWhitelist, getAllUsers, deleteUser, makeAdmin, removeAdmin } = useAuth()

  const [newEmail, setNewEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [users, setUsers] = useState(getAllUsers())

  useEffect(() => {
    setUsers(getAllUsers())
  }, [])

  const handleAddToWhitelist = async () => {
    if (!newEmail.trim()) return

    setIsLoading(true)
    setMessage(null)

    const success = await addToWhitelist(newEmail.trim())

    if (success) {
      setMessage({ type: "success", text: `Invitasjon sendt til ${newEmail}` })
      setNewEmail("")
    } else {
      setMessage({ type: "error", text: "Kunne ikke sende invitasjon. E-post kan allerede være invitert." })
    }

    setIsLoading(false)
  }

  const handleDeleteUser = (userId: string) => {
    if (confirm("Er du sikker på at du vil slette denne brukeren?")) {
      deleteUser(userId)
      setUsers(getAllUsers())
      setMessage({ type: "success", text: "Bruker slettet" })
    }
  }

  const handleMakeAdmin = (userId: string) => {
    makeAdmin(userId)
    setUsers(getAllUsers())
    setMessage({ type: "success", text: "Bruker gjort til administrator" })
  }

  const handleRemoveAdmin = (userId: string) => {
    if (confirm("Er du sikker på at du vil fjerne administrator-tilgang?")) {
      removeAdmin(userId)
      setUsers(getAllUsers())
      setMessage({ type: "success", text: "Administrator-tilgang fjernet" })
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("no-NO", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const stats = {
    totalUsers: users.length,
    totalInvites: whitelist.length,
    pendingInvites: whitelist.filter((w) => !w.isUsed).length,
    usedInvites: whitelist.filter((w) => w.isUsed).length,
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Administrer brukere og tilgang til Vital Few AI</p>
        </div>
      </div>

      {message && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Brukere</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale Invitasjoner</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalInvites}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventende Invitasjoner</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingInvites}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Brukte Invitasjoner</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.usedInvites}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="invite" className="space-y-4">
        <TabsList>
          <TabsTrigger value="invite">Inviter Brukere</TabsTrigger>
          <TabsTrigger value="whitelist">Whitelist</TabsTrigger>
          <TabsTrigger value="users">Brukere</TabsTrigger>
        </TabsList>

        <TabsContent value="invite" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Inviter Ny Bruker</CardTitle>
              <CardDescription>
                Send en invitasjon til en ny bruker. De vil motta en e-post med instruksjoner for å registrere seg.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label htmlFor="email">E-postadresse</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="bruker@eksempel.no"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAddToWhitelist()}
                  />
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={handleAddToWhitelist}
                    disabled={isLoading || !newEmail.trim()}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    {isLoading ? "Sender..." : "Send Invitasjon"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="whitelist" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Whitelist Oversikt</CardTitle>
              <CardDescription>Alle inviterte e-postadresser og deres status.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>E-post</TableHead>
                    <TableHead>Invitert av</TableHead>
                    <TableHead>Dato</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[100px]">Handlinger</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {whitelist.map((entry) => (
                    <TableRow key={entry.id}>
                      <TableCell className="font-medium">{entry.email}</TableCell>
                      <TableCell>{entry.invitedBy}</TableCell>
                      <TableCell>{formatDate(entry.invitedAt)}</TableCell>
                      <TableCell>
                        {entry.isUsed ? (
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Registrert
                          </Badge>
                        ) : (
                          <Badge variant="secondary">
                            <Clock className="h-3 w-3 mr-1" />
                            Venter
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => removeFromWhitelist(entry.id)}
                              className="text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Fjern
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Registrerte Brukere</CardTitle>
              <CardDescription>Alle brukere som har registrert seg på plattformen.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Navn</TableHead>
                    <TableHead>E-post</TableHead>
                    <TableHead>Registrert</TableHead>
                    <TableHead>Rolle</TableHead>
                    <TableHead className="w-[100px]">Handlinger</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                      <TableCell>
                        {user.isAdmin ? (
                          <Badge variant="default" className="bg-purple-100 text-purple-800">
                            <ShieldCheck className="h-3 w-3 mr-1" />
                            Admin
                          </Badge>
                        ) : (
                          <Badge variant="secondary">
                            <Shield className="h-3 w-3 mr-1" />
                            Bruker
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {!user.isAdmin ? (
                              <DropdownMenuItem onClick={() => handleMakeAdmin(user.id)}>
                                <ShieldCheck className="h-4 w-4 mr-2" />
                                Gjør til Admin
                              </DropdownMenuItem>
                            ) : (
                              user.email !== "admin@vitalfew.com" && (
                                <DropdownMenuItem onClick={() => handleRemoveAdmin(user.id)}>
                                  <Shield className="h-4 w-4 mr-2" />
                                  Fjern Admin
                                </DropdownMenuItem>
                              )
                            )}
                            {user.email !== "admin@vitalfew.com" && (
                              <DropdownMenuItem onClick={() => handleDeleteUser(user.id)} className="text-destructive">
                                <Trash2 className="h-4 w-4 mr-2" />
                                Slett Bruker
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
