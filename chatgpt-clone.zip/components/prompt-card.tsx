"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Star, Copy, MoreVertical, Edit, Trash2, Eye } from "lucide-react"
import { CATEGORIES, AI_MODELS, type Prompt } from "@/types/prompt"

interface PromptCardProps {
  prompt: Prompt
  onEdit: () => void
  onDelete: () => void
  onView: () => void
  onCopy: () => void
  onToggleFavorite: () => void
}

export function PromptCard({ prompt, onEdit, onDelete, onView, onCopy, onToggleFavorite }: PromptCardProps) {
  const [copied, setCopied] = useState(false)
  const category = CATEGORIES[prompt.category]
  const aiModel = AI_MODELS[prompt.aiModel]

  const handleCopy = () => {
    onCopy()
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} className={`h-3 w-3 ${i < rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`} />
    ))
  }

  return (
    <Card className="group hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3
              className="font-semibold text-sm leading-tight cursor-pointer hover:text-primary transition-colors line-clamp-2"
              onClick={onView}
            >
              {prompt.title}
            </h3>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="secondary" className={`${category.bgColor} ${category.textColor} border-0 text-xs`}>
                {category.name}
              </Badge>
              <div className="flex items-center gap-1">
                <span className="text-xs">{aiModel.icon}</span>
                <span className="text-xs text-muted-foreground">{aiModel.name}</span>
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onView}>
                <Eye className="h-4 w-4 mr-2" />
                Vis detaljer
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onEdit}>
                <Edit className="h-4 w-4 mr-2" />
                Rediger
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onDelete} className="text-destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Slett
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>

      <CardContent className="py-0">
        <p className="text-sm text-muted-foreground line-clamp-3 mb-3">{prompt.description}</p>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-1">{renderStars(prompt.rating)}</div>
          <span>Brukt {prompt.usageCount} ganger</span>
        </div>
      </CardContent>

      <CardFooter className="pt-3">
        <div className="flex items-center justify-between w-full">
          <div className="flex flex-wrap gap-1">
            {prompt.tags.slice(0, 2).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
            {prompt.tags.length > 2 && (
              <Badge variant="outline" className="text-xs">
                +{prompt.tags.length - 2}
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onToggleFavorite}>
              <Star className={`h-4 w-4 ${prompt.isFavorite ? "fill-yellow-400 text-yellow-400" : ""}`} />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleCopy}>
              <Copy className={`h-4 w-4 ${copied ? "text-green-500" : ""}`} />
            </Button>
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}
