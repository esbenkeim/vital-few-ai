"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X, BarChart3 } from "lucide-react"
import { CATEGORIES, AI_MODELS, type Category, type AIModel, type SortOption, type Prompt } from "@/types/prompt"

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
  selectedCategory: Category | "all"
  onCategoryChange: (category: Category | "all") => void
  selectedModel: AIModel | "all"
  onModelChange: (model: AIModel | "all") => void
  sortBy: SortOption
  onSortChange: (sort: SortOption) => void
  prompts: Prompt[]
}

export function Sidebar({
  isOpen,
  onClose,
  selectedCategory,
  onCategoryChange,
  selectedModel,
  onModelChange,
  sortBy,
  onSortChange,
  prompts,
}: SidebarProps) {
  const categoryStats = Object.keys(CATEGORIES).reduce(
    (acc, category) => {
      acc[category as Category] = prompts.filter((p) => p.category === category).length
      return acc
    },
    {} as Record<Category, number>,
  )

  const favoriteCount = prompts.filter((p) => p.isFavorite).length
  const totalUsage = prompts.reduce((sum, p) => sum + p.usageCount, 0)

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && <div className="fixed inset-0 z-40 bg-black/50 md:hidden" onClick={onClose} />}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-16 left-0 z-50 h-[calc(100vh-4rem)] w-80 transform border-r bg-background transition-transform duration-200 ease-in-out
          md:relative md:top-0 md:h-[calc(100vh-4rem)] md:translate-x-0
          ${isOpen ? "translate-x-0" : "-translate-x-full"}
        `}
      >
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between p-4 border-b md:hidden">
            <h2 className="text-lg font-semibold">Filtre</h2>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Statistics */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Statistikk
              </h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="bg-muted/50 rounded-lg p-3">
                  <div className="font-medium">{prompts.length}</div>
                  <div className="text-muted-foreground">Totale prompts</div>
                </div>
                <div className="bg-muted/50 rounded-lg p-3">
                  <div className="font-medium">{favoriteCount}</div>
                  <div className="text-muted-foreground">Favoritter</div>
                </div>
                <div className="bg-muted/50 rounded-lg p-3 col-span-2">
                  <div className="font-medium">{totalUsage}</div>
                  <div className="text-muted-foreground">Total bruk</div>
                </div>
              </div>
            </div>

            {/* Categories */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Kategorier</h3>
              <div className="space-y-1">
                <Button
                  variant={selectedCategory === "all" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => onCategoryChange("all")}
                >
                  Alle kategorier
                  <Badge variant="secondary" className="ml-auto">
                    {prompts.length}
                  </Badge>
                </Button>
                {Object.entries(CATEGORIES).map(([key, category]) => (
                  <Button
                    key={key}
                    variant={selectedCategory === key ? "secondary" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => onCategoryChange(key as Category)}
                  >
                    <div className={`w-3 h-3 rounded-full ${category.color} mr-2`} />
                    {category.name}
                    <Badge variant="secondary" className="ml-auto">
                      {categoryStats[key as Category] || 0}
                    </Badge>
                  </Button>
                ))}
              </div>
            </div>

            {/* AI Models */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium">AI Modell</h3>
              <Select value={selectedModel} onValueChange={(value) => onModelChange(value as AIModel | "all")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle modeller</SelectItem>
                  {Object.entries(AI_MODELS).map(([key, model]) => (
                    <SelectItem key={key} value={key}>
                      {model.icon} {model.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Sort */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Sortering</h3>
              <Select value={sortBy} onValueChange={(value) => onSortChange(value as SortOption)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Nyeste først</SelectItem>
                  <SelectItem value="oldest">Eldste først</SelectItem>
                  <SelectItem value="mostUsed">Mest brukt</SelectItem>
                  <SelectItem value="rating">Høyest rating</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </aside>
    </>
  )
}
