"use client"

import type React from "react"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ThemeToggle } from "@/components/theme-toggle"
import { Search, Plus, Menu, Download, Upload } from "lucide-react"
import Image from "next/image"

interface HeaderProps {
  searchQuery: string
  onSearchChange: (query: string) => void
  onAddPrompt: () => void
  onToggleSidebar: () => void
  onExport: () => void
  onImport: (file: File) => void
}

export function Header({ searchQuery, onSearchChange, onAddPrompt, onToggleSidebar, onExport, onImport }: HeaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      onImport(file)
      e.target.value = ""
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center px-4">
        <Button variant="ghost" size="icon" className="mr-2 md:hidden" onClick={onToggleSidebar}>
          <Menu className="h-5 w-5" />
        </Button>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-3">
            <Image
              src="/images/vital-few-logo.png"
              alt="Vital Few Logo"
              width={40}
              height={40}
              className="object-contain"
            />
            <div className="hidden sm:block">
              <h1 className="text-xl font-bold text-foreground">AI Prompt Bibliotek</h1>
              <p className="text-xs text-muted-foreground">Powered by Vital Few</p>
            </div>
          </div>
        </div>

        <div className="flex-1 max-w-md mx-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Søk i prompts..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={onExport}>
            <Download className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Eksporter</span>
          </Button>

          <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
            <Upload className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Importer</span>
          </Button>

          <input ref={fileInputRef} type="file" accept=".json" onChange={handleImport} className="hidden" />

          <Button
            onClick={onAddPrompt}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Ny Prompt</span>
          </Button>

          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}
