"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Copy, Edit, Star, Calendar, BarChart3 } from "lucide-react"
import { CATEGORIES, AI_MODELS, type Prompt } from "@/types/prompt"

interface PromptDetailModalProps {
  isOpen: boolean
  onClose: () => void
  prompt: Prompt | null
  onCopy: (content: string) => void
  onEdit: (prompt: Prompt) => void
}

export function PromptDetailModal({ isOpen, onClose, prompt, onCopy, onEdit }: PromptDetailModalProps) {
  const [copied, setCopied] = useState(false)

  if (!prompt) return null

  const category = CATEGORIES[prompt.category]
  const aiModel = AI_MODELS[prompt.aiModel]

  const handleCopy = () => {
    onCopy(prompt.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleEdit = () => {
    onEdit(prompt)
    onClose()
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} className={`h-4 w-4 ${i < rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`} />
    ))
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("no-NO", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <DialogTitle className="text-xl mb-2">{prompt.title}</DialogTitle>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary" className={`${category.bgColor} ${category.textColor} border-0`}>
                  {category.name}
                </Badge>
                <div className="flex items-center gap-1">
                  <span>{aiModel.icon}</span>
                  <span className="text-sm text-muted-foreground">{aiModel.name}</span>
                </div>
                {prompt.isFavorite && (
                  <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                    <Star className="h-3 w-3 mr-1 fill-yellow-400" />
                    Favoritt
                  </Badge>
                )}
              </div>
              <p className="text-muted-foreground">{prompt.description}</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleEdit}>
                <Edit className="h-4 w-4 mr-2" />
                Rediger
              </Button>
              <Button onClick={handleCopy}>
                <Copy className={`h-4 w-4 mr-2 ${copied ? "text-green-500" : ""}`} />
                {copied ? "Kopiert!" : "Kopier"}
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-center mb-1">{renderStars(prompt.rating)}</div>
              <div className="text-sm text-muted-foreground">Rating</div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 mb-1">
                <BarChart3 className="h-4 w-4" />
                <span className="font-medium">{prompt.usageCount}</span>
              </div>
              <div className="text-sm text-muted-foreground">Ganger brukt</div>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Calendar className="h-4 w-4" />
                <span className="font-medium text-sm">{formatDate(prompt.createdAt)}</span>
              </div>
              <div className="text-sm text-muted-foreground">Opprettet</div>
            </div>
          </div>

          <Separator />

          {/* Tags */}
          {prompt.tags.length > 0 && (
            <div>
              <h3 className="text-sm font-medium mb-2">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {prompt.tags.map((tag) => (
                  <Badge key={tag} variant="outline">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <Separator />

          {/* Prompt Content */}
          <div>
            <h3 className="text-sm font-medium mb-3">Prompt Innhold</h3>
            <div className="bg-muted/50 rounded-lg p-4">
              <pre className="whitespace-pre-wrap text-sm font-mono leading-relaxed">{prompt.content}</pre>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
