"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Github,
  Upload,
  Settings,
  Globe,
  Copy,
  CheckCircle,
  ExternalLink,
  FolderPlus,
  Zap,
  Info,
  AlertTriangle,
} from "lucide-react"
import { toast } from "sonner"

export function GitHubSetupGuide() {
  const [currentStep, setCurrentStep] = useState(1)
  const [copied, setCopied] = useState("")

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    setCopied(label)
    setTimeout(() => setCopied(""), 2000)
    toast.success(`${label} copied to clipboard!`)
  }

  const steps = [
    {
      id: 1,
      title: "Opprett nytt repository",
      description: "Lag et nytt repository på GitHub for prosjektet ditt",
      icon: <FolderPlus className="h-5 w-5" />,
    },
    {
      id: 2,
      title: "Last opp koden",
      description: "Last opp Vital Few AI koden til ditt repository",
      icon: <Upload className="h-5 w-5" />,
    },
    {
      id: 3,
      title: "Aktiver GitHub Pages",
      description: "Konfigurer GitHub Pages for å hoste nettsiden din",
      icon: <Globe className="h-5 w-5" />,
    },
    {
      id: 4,
      title: "Konfigurer deployment",
      description: "Sett opp automatisk deployment med GitHub Actions",
      icon: <Settings className="h-5 w-5" />,
    },
  ]

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2 bg-gray-900 hover:bg-gray-800 text-white">
          <Github className="h-4 w-4" />
          GitHub Setup Guide
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Github className="h-5 w-5" />
            GitHub Setup Guide for Beginners
          </DialogTitle>
          <DialogDescription>Complete step-by-step guide to deploy Vital Few AI on GitHub Pages</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress Steps */}
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    currentStep >= step.id ? "bg-blue-600 border-blue-600 text-white" : "border-gray-300 text-gray-400"
                  }`}
                >
                  {currentStep > step.id ? <CheckCircle className="h-5 w-5" /> : step.icon}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-16 h-0.5 mx-2 ${currentStep > step.id ? "bg-blue-600" : "bg-gray-300"}`} />
                )}
              </div>
            ))}
          </div>

          <div className="text-center">
            <h3 className="text-lg font-semibold">{steps[currentStep - 1].title}</h3>
            <p className="text-muted-foreground">{steps[currentStep - 1].description}</p>
          </div>

          <Tabs value={currentStep.toString()} onValueChange={(value) => setCurrentStep(Number.parseInt(value))}>
            <TabsList className="grid w-full grid-cols-4">
              {steps.map((step) => (
                <TabsTrigger key={step.id} value={step.id.toString()} className="text-xs">
                  Steg {step.id}
                </TabsTrigger>
              ))}
            </TabsList>

            {/* Step 1: Create Repository */}
            <TabsContent value="1" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FolderPlus className="h-5 w-5" />
                    Steg 1: Opprett nytt repository
                  </CardTitle>
                  <CardDescription>Vi skal lage et nytt repository på GitHub hvor koden din vil ligge</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
                        1
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Gå til GitHub</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Åpne{" "}
                          <a
                            href="https://github.com"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline inline-flex items-center gap-1"
                          >
                            github.com <ExternalLink className="h-3 w-3" />
                          </a>{" "}
                          og logg inn med kontoen din
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
                        2
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Klikk på "New repository"</h4>
                        <p className="text-sm text-muted-foreground">
                          Du finner denne knappen øverst til høyre, eller på hovedsiden din
                        </p>
                        <div className="mt-2 p-3 bg-muted/50 rounded-lg">
                          <p className="text-sm">
                            💡 <strong>Tips:</strong> Knappen er grønn og står "New"
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
                        3
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Fyll ut repository-informasjon</h4>
                        <div className="space-y-2 mt-2">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="text-sm font-medium">Repository name:</label>
                              <div className="flex items-center gap-2 mt-1">
                                <code className="bg-muted px-2 py-1 rounded text-sm">vital-few-ai</code>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => copyToClipboard("vital-few-ai", "Repository name")}
                                >
                                  {copied === "Repository name" ? (
                                    <CheckCircle className="h-3 w-3 text-green-600" />
                                  ) : (
                                    <Copy className="h-3 w-3" />
                                  )}
                                </Button>
                              </div>
                            </div>
                            <div>
                              <label className="text-sm font-medium">Visibility:</label>
                              <p className="text-sm text-muted-foreground mt-1">Velg "Public" (gratis)</p>
                            </div>
                          </div>
                          <div>
                            <label className="text-sm font-medium">Description (valgfritt):</label>
                            <div className="flex items-center gap-2 mt-1">
                              <code className="bg-muted px-2 py-1 rounded text-sm">
                                AI Prompt Library & Chat Platform
                              </code>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyToClipboard("AI Prompt Library & Chat Platform", "Description")}
                              >
                                {copied === "Description" ? (
                                  <CheckCircle className="h-3 w-3 text-green-600" />
                                ) : (
                                  <Copy className="h-3 w-3" />
                                )}
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
                        4
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Kryss av for "Add a README file"</h4>
                        <p className="text-sm text-muted-foreground">Dette gjør det enklere å komme i gang</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
                        5
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Klikk "Create repository"</h4>
                        <p className="text-sm text-muted-foreground">Den grønne knappen nederst på siden</p>
                      </div>
                    </div>
                  </div>

                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Gratulerer!</strong> Du har nå opprettet ditt første GitHub repository. URL-en vil være:{" "}
                      <code>https://github.com/ditt-brukernavn/vital-few-ai</code>
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Step 2: Upload Code */}
            <TabsContent value="2" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    Steg 2: Last opp koden
                  </CardTitle>
                  <CardDescription>Vi skal laste opp Vital Few AI koden til ditt nye repository</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      Du kan velge mellom to metoder: <strong>Web interface</strong> (enklest) eller{" "}
                      <strong>Git kommandoer</strong> (mer avansert)
                    </AlertDescription>
                  </Alert>

                  <Tabs defaultValue="web" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="web">Web Interface (Anbefalt)</TabsTrigger>
                      <TabsTrigger value="git">Git Kommandoer</TabsTrigger>
                    </TabsList>

                    <TabsContent value="web" className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
                            1
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">Last ned koden fra v0</h4>
                            <p className="text-sm text-muted-foreground">
                              Klikk på "Download Code" knappen øverst i v0 for å laste ned ZIP-filen
                            </p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
                            2
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">Pakk ut ZIP-filen</h4>
                            <p className="text-sm text-muted-foreground">
                              Pakk ut filene til en mappe på datamaskinen din
                            </p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
                            3
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">Gå til ditt repository på GitHub</h4>
                            <p className="text-sm text-muted-foreground">Åpne repository-siden du nettopp opprettet</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
                            4
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">Klikk "uploading an existing file"</h4>
                            <p className="text-sm text-muted-foreground">
                              Du finner denne linken i den blå boksen på repository-siden
                            </p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
                            5
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">Dra og slipp alle filene</h4>
                            <p className="text-sm text-muted-foreground">
                              Dra alle filene fra den utpakkede mappen til GitHub-siden
                            </p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
                            6
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">Skriv en commit-melding</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <code className="bg-muted px-2 py-1 rounded text-sm">
                                Initial commit: Add Vital Few AI
                              </code>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyToClipboard("Initial commit: Add Vital Few AI", "Commit message")}
                              >
                                {copied === "Commit message" ? (
                                  <CheckCircle className="h-3 w-3 text-green-600" />
                                ) : (
                                  <Copy className="h-3 w-3" />
                                )}
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
                            7
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">Klikk "Commit changes"</h4>
                            <p className="text-sm text-muted-foreground">Den grønne knappen nederst på siden</p>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="git" className="space-y-4">
                      <Alert>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          Denne metoden krever at du har Git installert på datamaskinen din.
                        </AlertDescription>
                      </Alert>

                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium mb-2">1. Klon repository</h4>
                          <div className="bg-gray-900 text-gray-100 p-3 rounded-lg font-mono text-sm">
                            <div className="flex items-center justify-between">
                              <span>git clone https://github.com/ditt-brukernavn/vital-few-ai.git</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-gray-400 hover:text-white"
                                onClick={() =>
                                  copyToClipboard(
                                    "git clone https://github.com/ditt-brukernavn/vital-few-ai.git",
                                    "Git clone",
                                  )
                                }
                              >
                                {copied === "Git clone" ? (
                                  <CheckCircle className="h-3 w-3" />
                                ) : (
                                  <Copy className="h-3 w-3" />
                                )}
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">2. Gå inn i mappen</h4>
                          <div className="bg-gray-900 text-gray-100 p-3 rounded-lg font-mono text-sm">
                            cd vital-few-ai
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">3. Kopier filene fra v0</h4>
                          <p className="text-sm text-muted-foreground">
                            Kopier alle filene fra den nedlastede v0-koden til denne mappen
                          </p>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">4. Legg til og commit filene</h4>
                          <div className="bg-gray-900 text-gray-100 p-3 rounded-lg font-mono text-sm space-y-1">
                            <div>git add .</div>
                            <div>git commit -m "Initial commit: Add Vital Few AI"</div>
                            <div>git push origin main</div>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Step 3: Enable GitHub Pages */}
            <TabsContent value="3" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    Steg 3: Aktiver GitHub Pages
                  </CardTitle>
                  <CardDescription>Nå skal vi aktivere GitHub Pages for å hoste nettsiden din gratis</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
                        1
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Gå til repository Settings</h4>
                        <p className="text-sm text-muted-foreground">
                          Klikk på "Settings" fanen øverst på repository-siden din
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
                        2
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Finn "Pages" i venstre meny</h4>
                        <p className="text-sm text-muted-foreground">Scroll ned i venstre meny til du finner "Pages"</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
                        3
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Velg "GitHub Actions" som source</h4>
                        <p className="text-sm text-muted-foreground">
                          Under "Source", velg "GitHub Actions" i stedet for "Deploy from a branch"
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
                        4
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Velg "Next.js" workflow</h4>
                        <p className="text-sm text-muted-foreground">
                          GitHub vil foreslå en Next.js workflow - klikk "Configure" på denne
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
                        5
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Commit workflow-filen</h4>
                        <p className="text-sm text-muted-foreground">
                          Klikk "Commit changes" for å lagre GitHub Actions workflow
                        </p>
                      </div>
                    </div>
                  </div>

                  <Alert>
                    <Zap className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Automatisk deployment!</strong> Fra nå av vil nettsiden din oppdateres automatisk hver
                      gang du endrer koden.
                    </AlertDescription>
                  </Alert>

                  <div className="bg-muted/50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Din nettside vil være tilgjengelig på:</h4>
                    <code className="text-sm bg-background px-2 py-1 rounded">
                      https://ditt-brukernavn.github.io/vital-few-ai
                    </code>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Step 4: Configure Deployment */}
            <TabsContent value="4" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Steg 4: Konfigurer deployment
                  </CardTitle>
                  <CardDescription>Siste steg - legg til environment variables for AI-funksjonalitet</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
                        1
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Gå til repository Settings → Secrets and variables → Actions</h4>
                        <p className="text-sm text-muted-foreground">
                          Her legger vi til API-nøklene dine på en sikker måte
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
                        2
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Klikk "New repository secret"</h4>
                        <p className="text-sm text-muted-foreground">Legg til følgende secrets en etter en:</p>
                        <div className="mt-2 space-y-2">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div className="font-medium">Secret Name</div>
                            <div className="font-medium">Description</div>
                          </div>
                          <Separator />
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <code>GROQ_API_KEY</code>
                            <span>Din Groq API nøkkel (påkrevd for chat)</span>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <code>OPENAI_API_KEY</code>
                            <span>Din OpenAI API nøkkel (valgfritt)</span>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <code>RESEND_API_KEY</code>
                            <span>For e-post invitasjoner (valgfritt)</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
                        3
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Vent på deployment</h4>
                        <p className="text-sm text-muted-foreground">
                          Gå til "Actions" fanen for å se deployment-prosessen. Det tar vanligvis 2-5 minutter.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
                        4
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">Test nettsiden din!</h4>
                        <p className="text-sm text-muted-foreground">
                          Når deployment er ferdig, besøk nettsiden din og test at alt fungerer
                        </p>
                      </div>
                    </div>
                  </div>

                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Gratulerer! 🎉</strong> Du har nå deployed Vital Few AI på GitHub Pages. Nettsiden din er
                      tilgjengelig for hele verden!
                    </AlertDescription>
                  </Alert>

                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border">
                    <h4 className="font-medium mb-2">🚀 Neste steg:</h4>
                    <ul className="text-sm space-y-1">
                      <li>• Del URL-en din med venner og kolleger</li>
                      <li>• Tilpass designet og innholdet</li>
                      <li>• Legg til flere AI-modeller</li>
                      <li>• Oppgrader til eget domene senere hvis ønskelig</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Navigation Buttons */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
              disabled={currentStep === 1}
            >
              Forrige
            </Button>
            <Button
              onClick={() => setCurrentStep(Math.min(4, currentStep + 1))}
              disabled={currentStep === 4}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {currentStep === 4 ? "Ferdig!" : "Neste"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
