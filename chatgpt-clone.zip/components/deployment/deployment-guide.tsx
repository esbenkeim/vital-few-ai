"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Globe, ExternalLink, Copy, CheckCircle, Zap, Rocket, Info } from "lucide-react"
import { DEPLOYMENT_OPTIONS, CUSTOM_SUBDOMAIN_SUGGESTIONS } from "@/lib/deployment-config"
import { toast } from "sonner"

export function DeploymentGuide() {
  const [selectedPlatform, setSelectedPlatform] = useState("vercel")
  const [customSubdomain, setCustomSubdomain] = useState("")
  const [copied, setCopied] = useState(false)

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    toast.success("Copied to clipboard!")
  }

  const generateRandomSubdomain = () => {
    const suggestions = CUSTOM_SUBDOMAIN_SUGGESTIONS
    const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)]
    const randomNumber = Math.floor(Math.random() * 1000)
    setCustomSubdomain(`${randomSuggestion}-${randomNumber}`)
  }

  const currentPlatform = DEPLOYMENT_OPTIONS[selectedPlatform as keyof typeof DEPLOYMENT_OPTIONS]

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 bg-transparent">
          <Globe className="h-4 w-4" />
          Deploy & Get Custom URL
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Rocket className="h-5 w-5" />
            Deploy Vital Few AI with Custom URL
          </DialogTitle>
          <DialogDescription>
            Choose a platform to deploy your application and get a custom URL without buying a domain
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Platform Selection */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Choose Deployment Platform</h3>
            <Tabs value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="vercel">Vercel</TabsTrigger>
                <TabsTrigger value="netlify">Netlify</TabsTrigger>
                <TabsTrigger value="github">GitHub</TabsTrigger>
                <TabsTrigger value="railway">Railway</TabsTrigger>
                <TabsTrigger value="render">Render</TabsTrigger>
              </TabsList>

              {Object.entries(DEPLOYMENT_OPTIONS).map(([key, platform]) => (
                <TabsContent key={key} value={key} className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        {platform.name}
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Free
                        </Badge>
                      </CardTitle>
                      <CardDescription>{platform.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <ExternalLink className="h-4 w-4" />
                          <span className="font-medium">Example URL:</span>
                        </div>
                        <code className="text-sm bg-background px-2 py-1 rounded">{platform.example}</code>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2">Deployment Steps:</h4>
                        <ol className="list-decimal list-inside space-y-1 text-sm">
                          {platform.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>
          </div>

          <Separator />

          {/* Custom Subdomain Generator */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Custom Subdomain Ideas</h3>
            <div className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Label htmlFor="subdomain">Your Custom Subdomain</Label>
                  <Input
                    id="subdomain"
                    value={customSubdomain}
                    onChange={(e) => setCustomSubdomain(e.target.value)}
                    placeholder="Enter your desired subdomain"
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={generateRandomSubdomain} variant="outline">
                    <Zap className="h-4 w-4 mr-2" />
                    Generate
                  </Button>
                </div>
              </div>

              {customSubdomain && (
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Your URL will be:{" "}
                    <code className="bg-muted px-1 py-0.5 rounded text-sm">
                      https://{customSubdomain}.
                      {selectedPlatform === "vercel"
                        ? "vercel.app"
                        : selectedPlatform === "netlify"
                          ? "netlify.app"
                          : selectedPlatform === "github"
                            ? "github.io"
                            : selectedPlatform === "railway"
                              ? "railway.app"
                              : "onrender.com"}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 ml-2"
                      onClick={() =>
                        copyToClipboard(
                          `https://${customSubdomain}.${
                            selectedPlatform === "vercel"
                              ? "vercel.app"
                              : selectedPlatform === "netlify"
                                ? "netlify.app"
                                : selectedPlatform === "github"
                                  ? "github.io"
                                  : selectedPlatform === "railway"
                                    ? "railway.app"
                                    : "onrender.com"
                          }`,
                        )
                      }
                    >
                      {copied ? <CheckCircle className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    </Button>
                  </AlertDescription>
                </Alert>
              )}

              <div>
                <Label className="text-sm font-medium">Suggested Subdomains:</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {CUSTOM_SUBDOMAIN_SUGGESTIONS.slice(0, 6).map((suggestion) => (
                    <Button key={suggestion} variant="outline" size="sm" onClick={() => setCustomSubdomain(suggestion)}>
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Detailed Instructions */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Step-by-Step Guide for {currentPlatform.name}</h3>

            {selectedPlatform === "vercel" && <VercelInstructions />}
            {selectedPlatform === "netlify" && <NetlifyInstructions />}
            {selectedPlatform === "github" && <GitHubInstructions />}
            {selectedPlatform === "railway" && <RailwayInstructions />}
            {selectedPlatform === "render" && <RenderInstructions />}
          </div>

          {/* Environment Variables */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Required Environment Variables</h3>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="font-medium">Variable</div>
                    <div className="font-medium">Description</div>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <code>GROQ_API_KEY</code>
                    <span>Your Groq API key for AI chat functionality</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <code>OPENAI_API_KEY</code>
                    <span>Your OpenAI API key (optional)</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <code>RESEND_API_KEY</code>
                    <span>For email invitations (optional)</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <code>NEXT_PUBLIC_APP_URL</code>
                    <span>Your deployed app URL</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function VercelInstructions() {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
              1
            </div>
            <div>
              <h4 className="font-medium">Connect GitHub Repository</h4>
              <p className="text-sm text-muted-foreground">
                Go to{" "}
                <a href="https://vercel.com" className="text-blue-600 hover:underline">
                  vercel.com
                </a>{" "}
                and sign in with GitHub
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
              2
            </div>
            <div>
              <h4 className="font-medium">Import Project</h4>
              <p className="text-sm text-muted-foreground">Click "New Project" and import your GitHub repository</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
              3
            </div>
            <div>
              <h4 className="font-medium">Configure Project</h4>
              <p className="text-sm text-muted-foreground">
                Vercel will auto-detect Next.js. Add your environment variables in the settings.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-sm font-medium">
              4
            </div>
            <div>
              <h4 className="font-medium">Custom Domain</h4>
              <p className="text-sm text-muted-foreground">
                In project settings, go to "Domains" and add your custom subdomain (e.g., vital-few-ai.vercel.app)
              </p>
            </div>
          </div>

          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Pro tip:</strong> Vercel automatically deploys on every push to your main branch!
            </AlertDescription>
          </Alert>
        </div>
      </CardContent>
    </Card>
  )
}

function NetlifyInstructions() {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
              1
            </div>
            <div>
              <h4 className="font-medium">Connect Repository</h4>
              <p className="text-sm text-muted-foreground">
                Go to{" "}
                <a href="https://netlify.com" className="text-blue-600 hover:underline">
                  netlify.com
                </a>{" "}
                and connect your GitHub repository
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
              2
            </div>
            <div>
              <h4 className="font-medium">Build Settings</h4>
              <p className="text-sm text-muted-foreground">
                Build command: <code className="bg-muted px-1 py-0.5 rounded">npm run build</code>
                <br />
                Publish directory: <code className="bg-muted px-1 py-0.5 rounded">out</code>
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
              3
            </div>
            <div>
              <h4 className="font-medium">Environment Variables</h4>
              <p className="text-sm text-muted-foreground">
                Add your environment variables in Site settings → Environment variables
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-green-100 text-green-800 flex items-center justify-center text-sm font-medium">
              4
            </div>
            <div>
              <h4 className="font-medium">Custom Domain</h4>
              <p className="text-sm text-muted-foreground">
                In Site settings → Domain management, change your site name to get a custom subdomain
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function GitHubInstructions() {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-gray-100 text-gray-800 flex items-center justify-center text-sm font-medium">
              1
            </div>
            <div>
              <h4 className="font-medium">Enable GitHub Pages</h4>
              <p className="text-sm text-muted-foreground">Go to your repository settings and enable GitHub Pages</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-gray-100 text-gray-800 flex items-center justify-center text-sm font-medium">
              2
            </div>
            <div>
              <h4 className="font-medium">Configure Next.js for Static Export</h4>
              <p className="text-sm text-muted-foreground">
                Add <code className="bg-muted px-1 py-0.5 rounded">output: 'export'</code> to your next.config.js
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-gray-100 text-gray-800 flex items-center justify-center text-sm font-medium">
              3
            </div>
            <div>
              <h4 className="font-medium">GitHub Actions</h4>
              <p className="text-sm text-muted-foreground">
                Set up GitHub Actions to automatically build and deploy your site
              </p>
            </div>
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Note:</strong> GitHub Pages works best for static sites. Some server-side features may need
              adjustment.
            </AlertDescription>
          </Alert>
        </div>
      </CardContent>
    </Card>
  )
}

function RailwayInstructions() {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
              1
            </div>
            <div>
              <h4 className="font-medium">Connect Repository</h4>
              <p className="text-sm text-muted-foreground">
                Go to{" "}
                <a href="https://railway.app" className="text-blue-600 hover:underline">
                  railway.app
                </a>{" "}
                and connect your GitHub repository
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
              2
            </div>
            <div>
              <h4 className="font-medium">Deploy Project</h4>
              <p className="text-sm text-muted-foreground">
                Railway will automatically detect Next.js and configure the build
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
              3
            </div>
            <div>
              <h4 className="font-medium">Environment Variables</h4>
              <p className="text-sm text-muted-foreground">Add your environment variables in the project settings</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-medium">
              4
            </div>
            <div>
              <h4 className="font-medium">Custom Domain</h4>
              <p className="text-sm text-muted-foreground">In project settings, you can configure a custom subdomain</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function RenderInstructions() {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
              1
            </div>
            <div>
              <h4 className="font-medium">Connect Repository</h4>
              <p className="text-sm text-muted-foreground">
                Go to{" "}
                <a href="https://render.com" className="text-blue-600 hover:underline">
                  render.com
                </a>{" "}
                and connect your GitHub repository
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
              2
            </div>
            <div>
              <h4 className="font-medium">Configure Service</h4>
              <p className="text-sm text-muted-foreground">
                Choose "Web Service" and configure build and start commands
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
              3
            </div>
            <div>
              <h4 className="font-medium">Environment Variables</h4>
              <p className="text-sm text-muted-foreground">Add your environment variables in the service settings</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center text-sm font-medium">
              4
            </div>
            <div>
              <h4 className="font-medium">Custom Domain</h4>
              <p className="text-sm text-muted-foreground">
                Your service will get a custom .onrender.com subdomain automatically
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
