"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Star,
  Clock,
  MessageSquare,
  FileText,
  TrendingUp,
  Zap,
  ChevronDown,
  ChevronRight,
  Pin,
  Archive,
} from "lucide-react"
import { useChatHistory } from "@/hooks/use-chat-history"
import { usePrompts } from "@/hooks/use-prompts"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface SmartSidebarProps {
  currentView: "chat" | "prompts" | "admin"
  onNavigate: (type: string, id?: string) => void
  isCollapsed?: boolean
}

export function SmartSidebar({ currentView, onNavigate, isCollapsed = false }: SmartSidebarProps) {
  const [recentOpen, setRecentOpen] = useState(true)
  const [favoritesOpen, setFavoritesOpen] = useState(true)
  const [pinnedItems, setPinnedItems] = useState<string[]>([])

  const { chatSessions } = useChatHistory()
  const { prompts } = usePrompts()

  // Load pinned items from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("vital-few-pinned")
    if (saved) {
      setPinnedItems(JSON.parse(saved))
    }
  }, [])

  // Save pinned items to localStorage
  useEffect(() => {
    localStorage.setItem("vital-few-pinned", JSON.stringify(pinnedItems))
  }, [pinnedItems])

  const togglePin = (id: string) => {
    setPinnedItems((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]))
  }

  const recentChats = chatSessions
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5)

  const favoritePrompts = prompts.filter((p) => p.isFavorite).slice(0, 5)
  const trendingPrompts = prompts.sort((a, b) => b.usageCount - a.usageCount).slice(0, 5)

  const pinnedChats = chatSessions.filter((chat) => pinnedItems.includes(`chat-${chat.id}`))
  const pinnedPrompts = prompts.filter((prompt) => pinnedItems.includes(`prompt-${prompt.id}`))

  if (isCollapsed) {
    return (
      <div className="w-16 border-r bg-muted/10 flex flex-col items-center py-4 gap-2">
        <Button variant="ghost" size="icon" onClick={() => onNavigate("new-chat")}>
          <MessageSquare className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => onNavigate("new-prompt")}>
          <FileText className="h-4 w-4" />
        </Button>
        <Separator className="w-8" />
        <Button variant="ghost" size="icon">
          <Star className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Clock className="h-4 w-4" />
        </Button>
      </div>
    )
  }

  return (
    <div className="w-80 border-r bg-muted/10 flex flex-col">
      <div className="p-4 border-b">
        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={() => onNavigate("new-chat")}
            className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            New Chat
          </Button>
          <Button size="sm" variant="outline" onClick={() => onNavigate("new-prompt")} className="flex-1">
            <FileText className="h-4 w-4 mr-2" />
            New Prompt
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Pinned Items */}
          {(pinnedChats.length > 0 || pinnedPrompts.length > 0) && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Pin className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-medium">Pinned</h3>
              </div>
              <div className="space-y-1">
                {pinnedChats.map((chat) => (
                  <div key={chat.id} className="group flex items-center">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 justify-start h-auto p-2"
                      onClick={() => onNavigate("chat", chat.id)}
                    >
                      <MessageSquare className="h-3 w-3 mr-2 flex-shrink-0" />
                      <div className="flex-1 min-w-0 text-left">
                        <div className="text-sm truncate">{chat.title}</div>
                        <div className="text-xs text-muted-foreground">{chat.messages.length} messages</div>
                      </div>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 opacity-0 group-hover:opacity-100"
                      onClick={() => togglePin(`chat-${chat.id}`)}
                    >
                      <Pin className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
                {pinnedPrompts.map((prompt) => (
                  <div key={prompt.id} className="group flex items-center">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 justify-start h-auto p-2"
                      onClick={() => onNavigate("prompt", prompt.id)}
                    >
                      <FileText className="h-3 w-3 mr-2 flex-shrink-0" />
                      <div className="flex-1 min-w-0 text-left">
                        <div className="text-sm truncate">{prompt.title}</div>
                        <div className="text-xs text-muted-foreground">Used {prompt.usageCount} times</div>
                      </div>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 opacity-0 group-hover:opacity-100"
                      onClick={() => togglePin(`prompt-${prompt.id}`)}
                    >
                      <Pin className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent Activity */}
          <Collapsible open={recentOpen} onOpenChange={setRecentOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className="w-full justify-between p-0 h-auto">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <h3 className="text-sm font-medium">Recent</h3>
                </div>
                {recentOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-1 mt-3">
              {recentChats.map((chat) => (
                <div key={chat.id} className="group flex items-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex-1 justify-start h-auto p-2"
                    onClick={() => onNavigate("chat", chat.id)}
                  >
                    <MessageSquare className="h-3 w-3 mr-2 flex-shrink-0" />
                    <div className="flex-1 min-w-0 text-left">
                      <div className="text-sm truncate">{chat.title}</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(chat.updatedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 opacity-0 group-hover:opacity-100"
                    onClick={() => togglePin(`chat-${chat.id}`)}
                  >
                    <Pin className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </CollapsibleContent>
          </Collapsible>

          {/* Favorites */}
          {favoritePrompts.length > 0 && (
            <Collapsible open={favoritesOpen} onOpenChange={setFavoritesOpen}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" className="w-full justify-between p-0 h-auto">
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-muted-foreground" />
                    <h3 className="text-sm font-medium">Favorites</h3>
                    <Badge variant="secondary" className="text-xs">
                      {favoritePrompts.length}
                    </Badge>
                  </div>
                  {favoritesOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-1 mt-3">
                {favoritePrompts.map((prompt) => (
                  <div key={prompt.id} className="group flex items-center">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 justify-start h-auto p-2"
                      onClick={() => onNavigate("prompt", prompt.id)}
                    >
                      <Star className="h-3 w-3 mr-2 flex-shrink-0 fill-yellow-400 text-yellow-400" />
                      <div className="flex-1 min-w-0 text-left">
                        <div className="text-sm truncate">{prompt.title}</div>
                        <div className="text-xs text-muted-foreground">{prompt.category}</div>
                      </div>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 opacity-0 group-hover:opacity-100"
                      onClick={() => togglePin(`prompt-${prompt.id}`)}
                    >
                      <Pin className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </CollapsibleContent>
            </Collapsible>
          )}

          {/* Trending */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-medium">Trending</h3>
            </div>
            <div className="space-y-1">
              {trendingPrompts.map((prompt) => (
                <Button
                  key={prompt.id}
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start h-auto p-2"
                  onClick={() => onNavigate("prompt", prompt.id)}
                >
                  <TrendingUp className="h-3 w-3 mr-2 flex-shrink-0" />
                  <div className="flex-1 min-w-0 text-left">
                    <div className="text-sm truncate">{prompt.title}</div>
                    <div className="text-xs text-muted-foreground">{prompt.usageCount} uses</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Zap className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-medium">Quick Actions</h3>
            </div>
            <div className="space-y-1">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start"
                onClick={() => onNavigate("export-data")}
              >
                <Archive className="h-4 w-4 mr-2" />
                Export Data
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start"
                onClick={() => onNavigate("import-data")}
              >
                <FileText className="h-4 w-4 mr-2" />
                Import Data
              </Button>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}
