"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MessageSquare, FileText, Settings, Search, Plus, ChevronRight, BookOpen, Users } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { GlobalSearch } from "./global-search"
import { DeploymentGuide } from "../deployment/deployment-guide"
import { GitHubSetupGuide } from "../deployment/github-setup-guide"
import Image from "next/image"

interface SmartNavbarProps {
  currentView: "chat" | "prompts" | "admin"
  onViewChange: (view: "chat" | "prompts" | "admin") => void
  onQuickAction: (action: string, data?: any) => void
  breadcrumbs?: Array<{ label: string; href?: string }>
}

export function SmartNavbar({ currentView, onViewChange, onQuickAction, breadcrumbs = [] }: SmartNavbarProps) {
  const [searchOpen, setSearchOpen] = useState(false)
  const { user, isAdmin } = useAuth()

  const handleGlobalSearch = () => {
    setSearchOpen(true)
  }

  const handleSearchNavigate = (type: string, id?: string) => {
    switch (type) {
      case "chat":
        onViewChange("chat")
        if (id) onQuickAction("select-chat", id)
        break
      case "prompt":
        onViewChange("prompts")
        if (id) onQuickAction("view-prompt", id)
        break
      case "new-chat":
        onViewChange("chat")
        onQuickAction("new-chat")
        break
      case "new-prompt":
        onViewChange("prompts")
        onQuickAction("new-prompt")
        break
      case "admin":
        if (isAdmin) onViewChange("admin")
        break
    }
    setSearchOpen(false)
  }

  const quickActions = [
    {
      id: "new-chat",
      label: "New Chat",
      icon: <MessageSquare className="h-4 w-4" />,
      action: () => {
        onViewChange("chat")
        onQuickAction("new-chat")
      },
      shortcut: "⌘N",
    },
    {
      id: "new-prompt",
      label: "New Prompt",
      icon: <FileText className="h-4 w-4" />,
      action: () => {
        onViewChange("prompts")
        onQuickAction("new-prompt")
      },
      shortcut: "⌘P",
    },
  ]

  const navigationItems = [
    {
      id: "chat",
      label: "Chat",
      icon: <MessageSquare className="h-4 w-4" />,
      view: "chat" as const,
      badge: null,
    },
    {
      id: "prompts",
      label: "Prompts",
      icon: <BookOpen className="h-4 w-4" />,
      view: "prompts" as const,
      badge: null,
    },
  ]

  if (isAdmin) {
    navigationItems.push({
      id: "admin",
      label: "Admin",
      icon: <Users className="h-4 w-4" />,
      view: "admin" as const,
      badge: (
        <Badge variant="secondary" className="bg-purple-100 text-purple-800 text-xs">
          Admin
        </Badge>
      ),
    })
  }

  return (
    <>
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center px-4">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3 mr-6">
            <Image
              src="/images/vital-few-logo.png"
              alt="Vital Few Logo"
              width={32}
              height={32}
              className="object-contain"
            />
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-foreground">Vital Few AI</h1>
            </div>
          </div>

          {/* Navigation Items */}
          <div className="flex items-center space-x-1 mr-6">
            {navigationItems.map((item) => (
              <Button
                key={item.id}
                variant={currentView === item.view ? "secondary" : "ghost"}
                size="sm"
                onClick={() => onViewChange(item.view)}
                className="flex items-center gap-2"
              >
                {item.icon}
                <span className="hidden sm:inline">{item.label}</span>
                {item.badge}
              </Button>
            ))}
          </div>

          {/* Breadcrumbs */}
          {breadcrumbs.length > 0 && (
            <div className="flex items-center space-x-2 mr-6 text-sm text-muted-foreground">
              {breadcrumbs.map((crumb, index) => (
                <div key={index} className="flex items-center space-x-2">
                  {index > 0 && <ChevronRight className="h-3 w-3" />}
                  <span className={index === breadcrumbs.length - 1 ? "text-foreground font-medium" : ""}>
                    {crumb.label}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Search */}
          <div className="flex-1 max-w-md mx-4">
            <Button
              variant="outline"
              className="w-full justify-start text-muted-foreground bg-transparent"
              onClick={handleGlobalSearch}
            >
              <Search className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Search everything...</span>
              <span className="sm:hidden">Search...</span>
              <Badge variant="outline" className="ml-auto text-xs">
                ⌘K
              </Badge>
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center space-x-2">
            {/* GitHub Setup Guide - Prominent for new users */}
            <GitHubSetupGuide />

            {/* Deployment Guide */}
            <DeploymentGuide />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  size="sm"
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">New</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {quickActions.map((action) => (
                  <DropdownMenuItem key={action.id} onClick={action.action}>
                    {action.icon}
                    <span className="ml-2">{action.label}</span>
                    <Badge variant="outline" className="ml-auto text-xs">
                      {action.shortcut}
                    </Badge>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                    <span className="text-xs text-white font-medium">{user?.name.charAt(0).toUpperCase()}</span>
                  </div>
                  <span className="hidden sm:inline">{user?.name}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <div className="px-2 py-1.5 text-sm">
                  <div className="font-medium">{user?.name}</div>
                  <div className="text-muted-foreground">{user?.email}</div>
                </div>
                <DropdownMenuItem onClick={() => onQuickAction("profile")}>
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onQuickAction("logout")}>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </nav>

      <GlobalSearch isOpen={searchOpen} onClose={() => setSearchOpen(false)} onNavigate={handleSearchNavigate} />
    </>
  )
}
