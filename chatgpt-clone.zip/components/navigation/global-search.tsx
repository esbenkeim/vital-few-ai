"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, MessageSquare, FileText, Settings, Zap } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { useChatHistory } from "@/hooks/use-chat-history"
import { usePrompts } from "@/hooks/use-prompts"

interface SearchResult {
  id: string
  title: string
  description: string
  type: "chat" | "prompt" | "user" | "admin"
  icon: React.ReactNode
  action: () => void
  metadata?: string
}

interface GlobalSearchProps {
  isOpen: boolean
  onClose: () => void
  onNavigate: (type: string, id?: string) => void
}

export function GlobalSearch({ isOpen, onClose, onNavigate }: GlobalSearchProps) {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>([])
  const [selectedIndex, setSelectedIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  const { chatSessions } = useChatHistory()
  const { prompts } = usePrompts()
  const { isAdmin } = useAuth()

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus()
      setQuery("")
      setSelectedIndex(0)
    }
  }, [isOpen])

  useEffect(() => {
    if (!query.trim()) {
      // Show recent items when no query
      const recentChats = chatSessions.slice(0, 3).map((chat) => ({
        id: chat.id,
        title: chat.title,
        description: `${chat.messages.length} messages • ${chat.model}`,
        type: "chat" as const,
        icon: <MessageSquare className="h-4 w-4" />,
        action: () => onNavigate("chat", chat.id),
        metadata: "Recent",
      }))

      const recentPrompts = prompts
        .sort((a, b) => b.usageCount - a.usageCount)
        .slice(0, 3)
        .map((prompt) => ({
          id: prompt.id,
          title: prompt.title,
          description: prompt.description,
          type: "prompt" as const,
          icon: <FileText className="h-4 w-4" />,
          action: () => onNavigate("prompt", prompt.id),
          metadata: `Used ${prompt.usageCount} times`,
        }))

      const quickActions = [
        {
          id: "new-chat",
          title: "New Chat",
          description: "Start a new conversation",
          type: "chat" as const,
          icon: <Zap className="h-4 w-4" />,
          action: () => onNavigate("new-chat"),
          metadata: "Quick Action",
        },
        {
          id: "new-prompt",
          title: "New Prompt",
          description: "Create a new prompt",
          type: "prompt" as const,
          icon: <Zap className="h-4 w-4" />,
          action: () => onNavigate("new-prompt"),
          metadata: "Quick Action",
        },
      ]

      if (isAdmin) {
        quickActions.push({
          id: "admin",
          title: "Admin Dashboard",
          description: "Manage users and access",
          type: "admin" as const,
          icon: <Settings className="h-4 w-4" />,
          action: () => onNavigate("admin"),
          metadata: "Admin",
        })
      }

      setResults([...quickActions, ...recentChats, ...recentPrompts])
      return
    }

    // Search functionality
    const searchResults: SearchResult[] = []
    const lowerQuery = query.toLowerCase()

    // Search chats
    chatSessions.forEach((chat) => {
      if (
        chat.title.toLowerCase().includes(lowerQuery) ||
        chat.messages.some((m) => m.content.toLowerCase().includes(lowerQuery))
      ) {
        searchResults.push({
          id: chat.id,
          title: chat.title,
          description: `${chat.messages.length} messages • ${chat.model}`,
          type: "chat",
          icon: <MessageSquare className="h-4 w-4" />,
          action: () => onNavigate("chat", chat.id),
          metadata: "Chat",
        })
      }
    })

    // Search prompts
    prompts.forEach((prompt) => {
      if (
        prompt.title.toLowerCase().includes(lowerQuery) ||
        prompt.description.toLowerCase().includes(lowerQuery) ||
        prompt.content.toLowerCase().includes(lowerQuery) ||
        prompt.tags.some((tag) => tag.toLowerCase().includes(lowerQuery))
      ) {
        searchResults.push({
          id: prompt.id,
          title: prompt.title,
          description: prompt.description,
          type: "prompt",
          icon: <FileText className="h-4 w-4" />,
          action: () => onNavigate("prompt", prompt.id),
          metadata: prompt.category,
        })
      }
    })

    setResults(searchResults)
    setSelectedIndex(0)
  }, [query, chatSessions, prompts, isAdmin, onNavigate])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    switch (e.key) {
      case "ArrowDown":
        e.preventDefault()
        setSelectedIndex((prev) => Math.min(prev + 1, results.length - 1))
        break
      case "ArrowUp":
        e.preventDefault()
        setSelectedIndex((prev) => Math.max(prev - 1, 0))
        break
      case "Enter":
        e.preventDefault()
        if (results[selectedIndex]) {
          results[selectedIndex].action()
          onClose()
        }
        break
      case "Escape":
        onClose()
        break
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "chat":
        return "bg-blue-100 text-blue-800"
      case "prompt":
        return "bg-green-100 text-green-800"
      case "admin":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0">
        <div className="flex items-center border-b px-4 py-3">
          <Search className="h-4 w-4 text-muted-foreground mr-3" />
          <Input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Search chats, prompts, or type a command..."
            className="border-0 focus-visible:ring-0 text-base"
          />
          <Badge variant="outline" className="ml-2 text-xs">
            ⌘K
          </Badge>
        </div>

        <ScrollArea className="max-h-96">
          <div className="p-2">
            {results.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No results found</p>
              </div>
            ) : (
              <div className="space-y-1">
                {results.map((result, index) => (
                  <Button
                    key={result.id}
                    variant={index === selectedIndex ? "secondary" : "ghost"}
                    className="w-full justify-start h-auto p-3 text-left"
                    onClick={() => {
                      result.action()
                      onClose()
                    }}
                  >
                    <div className="flex items-center gap-3 w-full">
                      <div className="flex-shrink-0">{result.icon}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium truncate">{result.title}</div>
                        <div className="text-sm text-muted-foreground truncate">{result.description}</div>
                      </div>
                      <Badge variant="outline" className={`text-xs ${getTypeColor(result.type)}`}>
                        {result.metadata || result.type}
                      </Badge>
                    </div>
                  </Button>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="border-t px-4 py-2 text-xs text-muted-foreground">
          <div className="flex items-center justify-between">
            <span>Use ↑↓ to navigate, ↵ to select, esc to close</span>
            <div className="flex gap-2">
              <Badge variant="outline">⌘K</Badge>
              <span>to search</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
